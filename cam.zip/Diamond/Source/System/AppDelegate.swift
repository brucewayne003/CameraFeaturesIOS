//
//  AppDelegate.swift
//  diamond-ios
//
//  Created by Andrew HunzekerHesed on 4/29/23.
//

import Combine
import Osiris
import OsirisDefaultResources
import UIKit

@main
@available(iOS 15.0, *)
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var coordinator: AppCoordinator?
    var cancellables: Set<AnyCancellable> = []
    @Provider var requestManager: RequestManagerProtocol = RequestManager()
    let userState: UserState = .shared
    let environmentManager: EnvironmentManager = .shared

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        OsirisDefaultResourceProvider().installForLegacyUI()

        window = UIWindow(frame: UIScreen.main.bounds)
        let navigationController = UINavigationController()
        coordinator = AppCoordinator(navigationController: navigationController)

        window?.rootViewController = navigationController
        window?.makeKeyAndVisible()

        setupSessionSubscriptions()
        setupServices()

        coordinator?.start()

        return true
    }
    
    // MARK: Private Helpers
    
    private func setupSessionSubscriptions() {
        userState.$session
            .dropFirst()
            .receive(on: DispatchQueue.main)
            .sink { [weak self] session in
            switch session {
            case .loggedOut, .expired:
                self?.coordinator?.showLogin()
            case .loggedIn:
                self?.coordinator?.showHomeTab()
            }
        }
        .store(in: &cancellables)
    }
    
    private func setupServices() {
        let settingsService = UserDefaultBarcodeSettingsService(defaults: .standard)
        BarcodeSettingsService.start(withService: settingsService)
    }
    
}
