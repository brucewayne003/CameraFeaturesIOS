import Foundation
import Osiris
import OsirisBarcode
import UIKit
import XCTest

final class HeadlessBarcodeDecoderTests: XCTestCase {
    func testDecodesGS1WithoutScannerOrUIResources() throws {
        let url = try XCTUnwrap(Bundle.module.url(
            forResource: "gs1-datamatrix", withExtension: "png", subdirectory: "Fixtures"
        ))
        let image = try XCTUnwrap(UIImage(data: Data(contentsOf: url)))
        let buffer = try XCTUnwrap(image.toCVPixelBuffer())
        var options = BarcodeDecoderOptions(decoderType: .zxing)
        options.formats = [.datamatrix]
        options.reticle = false
        let decoder = BarcodeDecoderManager.buildDecoder(forType: .zxing, options: options)
        let barcode = try decoder.decode(buffer).result.get()

        XCTAssertEqual(barcode.format, .datamatrix)
        XCTAssertTrue(barcode.symbologyIdentifier.hasPrefix("]d2"))
        XCTAssertEqual(barcode.gs1Data?.gtinResult, .success(gtin: "9504000059101", warning: nil))
    }
}
