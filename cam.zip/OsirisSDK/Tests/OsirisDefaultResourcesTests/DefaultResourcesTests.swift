import Foundation
import Osiris
import OsirisDefaultResources
import UIKit
import XCTest

final class DefaultResourcesTests: XCTestCase {
    @MainActor
    func testOptionalBundleContainsOriginalResources() throws {
        let provider = OsirisDefaultResourceProvider()
        XCTAssertNotNil(provider.color(named: "yellow100"))
        XCTAssertNotNil(provider.image(named: "ic_flash"))
        XCTAssertEqual(try XCTUnwrap(provider.font(named: "Bogle-Regular", size: 16)).fontName, "Bogle-Regular")
        let sound = try XCTUnwrap(provider.soundURL)
        XCTAssertEqual(sound.lastPathComponent, "scanbeep.wav")
        XCTAssertTrue(FileManager.default.fileExists(atPath: sound.path))
        XCTAssertEqual(provider.feedbackConfig().getFeedback()?.sound, sound)
        XCTAssertEqual(provider.boundingBoxConfig().borderColor, provider.color(named: "yellow100"))
    }

    @MainActor
    func testCreatingProviderDoesNotInstallItGlobally() {
        let previous = OsirisUIResourceRegistry.provider
        defer { OsirisUIResourceRegistry.provider = previous }
        OsirisUIResourceRegistry.provider = nil
        let provider = OsirisDefaultResourceProvider()
        XCTAssertNil(OsirisUIResourceRegistry.provider)
        provider.installForLegacyUI()
        XCTAssertTrue((OsirisUIResourceRegistry.provider as AnyObject?) === provider)
    }
}
