import Foundation
import UIKit
import XCTest
@testable import OsirisCamera
@testable import Osiris

final class ScannerResourceTests: XCTestCase {
    func testDefaultFeedbackHasNoSound() throws {
        let manager = ScannerBarcodeManager()
        manager.feedbackConfig = OsirisFeedbackConfig()
        let feedback = try XCTUnwrap(manager.getFeedback())
        XCTAssertTrue(feedback.enabled)
        XCTAssertNil(feedback.sound)
        guard case .medium? = feedback.vibration else {
            return XCTFail("Expected medium feedback")
        }
    }

    func testEmptyFeedbackMapDisablesFeedback() {
        let manager = ScannerBarcodeManager()
        manager.feedbackConfig = OsirisFeedbackConfig(eventFeedback: [:])
        XCTAssertNil(manager.getFeedback())
        XCTAssertNil(manager.audioPlayer)
    }

    func testSuccessOverridesStandardAndDisabledSuccessSuppressesFallback() {
        let manager = ScannerBarcodeManager()
        let standardURL = URL(fileURLWithPath: "/host/standard.wav")
        let successURL = URL(fileURLWithPath: "/host/success.wav")
        manager.feedbackConfig = OsirisFeedbackConfig(eventFeedback: [
            .standard: Feedback(vibration: .light, sound: standardURL),
            .success: Feedback(vibration: .heavy, sound: successURL)
        ])
        XCTAssertEqual(manager.getFeedback()?.sound, successURL)
        manager.feedbackConfig?.disableFeedback(forEvent: .success)
        XCTAssertNil(manager.getFeedback())
    }

    func testMissingSuccessUsesHostStandardSoundAndNilSoundStaysSilent() {
        let manager = ScannerBarcodeManager()
        let url = URL(fileURLWithPath: "/host/scan.wav")
        manager.feedbackConfig = OsirisFeedbackConfig(eventFeedback: [
            .standard: Feedback(vibration: nil, sound: url)
        ])
        XCTAssertEqual(manager.getFeedback()?.sound, url)
        manager.feedbackConfig?.setFeedback(Feedback(vibration: .light, sound: nil), forEvent: .success)
        XCTAssertNil(manager.getFeedback()?.sound)
    }

    @MainActor
    func testLegacyResourcesFallBackWithoutProvider() {
        let previous = OsirisUIResourceRegistry.provider
        defer { OsirisUIResourceRegistry.provider = previous }
        OsirisUIResourceRegistry.provider = nil

        XCTAssertEqual(UIFont.bogle(size: 17), UIFont.systemFont(ofSize: 17))
        XCTAssertEqual(UIColor.blueBrand, UIColor.systemBlue)
        XCTAssertNotNil(UIImage.flashIcon)
        XCTAssertNotNil(UIImage.topLeftFrameIcon)
    }

    @MainActor
    func testHostProviderSuppliesLegacyResources() {
        let previous = OsirisUIResourceRegistry.provider
        defer { OsirisUIResourceRegistry.provider = previous }
        let provider = HostResources()
        OsirisUIResourceRegistry.provider = provider

        XCTAssertEqual(UIColor.blueBrand, provider.color)
        XCTAssertTrue(UIImage.flashIcon === provider.image)
        XCTAssertEqual(UIFont.bogle(size: 17), provider.font)
    }

    @MainActor
    func testScannerAppearanceUsesItsOwnConfiguration() {
        let previous = OsirisUIResourceRegistry.provider
        defer { OsirisUIResourceRegistry.provider = previous }
        OsirisUIResourceRegistry.provider = HostResources()
        let first = OsirisScannerView(frame: .zero)
        let second = OsirisScannerView(frame: .zero)
        first.applyAppearance(OsirisScannerAppearance(reticleColor: .red, detectedReticleColor: .green))
        second.applyAppearance(OsirisScannerAppearance(reticleColor: .blue, detectedReticleColor: .orange))

        XCTAssertEqual(first.reticle.reticleColor, UIColor.red)
        XCTAssertEqual(first.reticle.detectedReticleColor, UIColor.green)
        XCTAssertEqual(second.reticle.reticleColor, UIColor.blue)
        XCTAssertEqual(second.reticle.detectedReticleColor, UIColor.orange)
    }
}

private final class HostResources: OsirisResourceProvider {
    let color = UIColor.magenta
    let image = UIImage()
    let font = UIFont.monospacedSystemFont(ofSize: 17, weight: .bold)

    func color(named name: String) -> UIColor? { color }
    func image(named name: String) -> UIImage? { image }
    func font(named name: String, size: CGFloat) -> UIFont? { font }
}
