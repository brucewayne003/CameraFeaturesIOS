//
//  OsirisFeedbackConfig.swift
//  Osiris
//
//  Created by Kyle McGinnis on 4/12/24.
//

import Foundation

/// `OsirisFeedbackConfig` maps different FeedbackEvents to sound/haptic feedback.  Use default `.standard`to map to successful barcode decoding feedback.
public struct OsirisFeedbackConfig {
    
    // MARK: Properties
    
    public private(set) var eventFeedback: [FeedbackEvent: Feedback]
    
    // MARK: Lifecycle
    
    /// `init` for OsirisFeedbackConfig
    /// - Parameter eventFeedback: [FeedbackEvent: Feedback] - mapping of FeedbackEvents to Feedback for Audio and Haptics
    public init(eventFeedback: [FeedbackEvent: Feedback] = [.standard: .init(vibration: .medium)]) {
        self.eventFeedback = eventFeedback
    }
    
    // MARK: API
    
    /// - Parameter forEvent: FeedbackEvent - event type allowing Feedback ( currently only `standard` and `success`)
    public func getFeedback(forEvent event: FeedbackEvent = .standard) -> Feedback? {
        eventFeedback[event]
    }
    
    /// setFeedback sets Feedback for this particular FeedbackEvent, replacing previously mapped
    /// - Parameter feedback: Feedback - sound/haptic feedback
    /// - Parameter forEvent: FeedbackEvent - event type allowing Feedback ( currently only `standard` and `success`)
    public mutating func setFeedback(_ feedback: Feedback, forEvent event: FeedbackEvent = .standard) {
        eventFeedback[event] = feedback
    }
    
    /// enableFeedback enables Feedback for a FeedbackEvent if it was previously set but disabled
    /// - Parameter forEvent: FeedbackEvent - event type allowing Feedback ( currently only `standard` and `success`)
    public mutating func enableFeedback(forEvent event: FeedbackEvent = .standard) {
        setEnableFeedback(forEvent: event, enabled: true)
    }
    
    /// disableFeedback disables Feedback for this event.  It doesn't remove the mapping entirely but disables feedback so that you can easily reenable it if needed.
    /// - Parameter forEvent: FeedbackEvent - event type allowing Feedback ( currently only `standard` and `success`)
    public mutating func disableFeedback(forEvent event: FeedbackEvent = .standard) {
        setEnableFeedback(forEvent: event, enabled: false)
    }
    
    // MARK: Private Helpers
    
    private mutating func setEnableFeedback(forEvent event: FeedbackEvent = .standard, enabled: Bool) {
        var feedback = getFeedback(forEvent: event) ?? .init()
        feedback.enabled = enabled
        eventFeedback[event] = feedback
    }
}

public class OsirisFeedbackHelper {
    @available(*, deprecated, message: "Supply Feedback.sound explicitly; core no longer bundles scanbeep.wav.")
    public static func defaultBeepURL() -> URL? {
        nil
    }
}
