import UIKit

public struct OsirisScannerAppearance {
    public var reticleColor: UIColor
    public var detectedReticleColor: UIColor

    public init(reticleColor: UIColor = .white,
                detectedReticleColor: UIColor = .systemYellow) {
        self.reticleColor = reticleColor
        self.detectedReticleColor = detectedReticleColor
    }
}
