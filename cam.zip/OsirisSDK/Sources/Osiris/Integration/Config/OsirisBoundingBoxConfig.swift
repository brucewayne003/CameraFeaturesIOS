//
//  OsirisBoundingBoxConfig.swift
//  
//
//  Created by Ahmed Bekhit on 10/14/24.
//

import UIKit
import Foundation

/// `OsirisBoundingBoxConfig` is the configuration used to customize the bounding box UI while scanning.
public struct OsirisBoundingBoxConfig {
    
    public struct TitleBox {
        public enum Positioning {
            case top
            case left
        }
        
        public let title: String
        public let titleColor: UIColor
        
        public let positioning: Positioning
        
        /// The font of the set title. Defaults to medium-weight system font of size 12.
        public let titleFont: UIFont
        
        /// The background color of the box. Default is `nil`. Hence, the background is transparent.
        public let backgroundColor: UIColor?
        
        /// The corner radius of the background. Default is `0`.
        public let backgroundCornerRadius: CGFloat
        
        public init(
            title: String,
            titleColor: UIColor,
            titleFont: UIFont = .systemFont(ofSize: 12, weight: .medium),
            positioning: Positioning = .top,
            backgroundColor: UIColor? = nil,
            backgroundCornerRadius: CGFloat = 0
        ) {
            self.title = title
            self.titleColor = titleColor
            self.positioning = positioning
            self.titleFont = titleFont
            self.backgroundColor = backgroundColor
            self.backgroundCornerRadius = backgroundCornerRadius
        }
    }
    
    // MARK: Properties
    
    /// The color of the surrounding border. Default is `yellow`.
    public internal(set) var borderColor: UIColor
    
    /// The background color of the box. Default is `nil`. Hence, the background is transparent.
    public internal(set) var backgroundColor: UIColor?
    
    /// The thickness of the surrounding border. Default is `3`.
    public internal(set) var borderThickness: CGFloat
    
    /// The corner radius of the surrounding border. Default is `0`.
    public internal(set) var borderCornerRadius: CGFloat

    /// The icon image to diplay in the center of the bounding box. Default is `nil`. Hence, no center icon will be displayed by default.
    public internal(set) var centerIconImage: UIImage?
    
    /// The title box to display on top of the bounding box. Default is `nil`. Hence, no title will be displayed by default.
    public internal(set) var titleBox: TitleBox?
    
    public init(
        borderColor: UIColor = .systemYellow,
        backgroundColor: UIColor? = nil,
        borderThickness: CGFloat = 3,
        borderCornerRadius: CGFloat = 0,
        centerIconImage: UIImage? = nil,
        titleBox: TitleBox? = nil
    ) {
        self.borderColor = borderColor
        self.backgroundColor = backgroundColor
        self.borderThickness = borderThickness
        self.borderCornerRadius = borderCornerRadius
        self.centerIconImage = centerIconImage
        self.titleBox = titleBox
    }
}
