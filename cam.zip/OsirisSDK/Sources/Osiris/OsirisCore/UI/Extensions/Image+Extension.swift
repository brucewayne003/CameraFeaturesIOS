//
//  Image+Extension.swift
//  Diamond
//
//  Created by Andres Vinueza on 5/1/23.
//

import SwiftUI
import UIKit

@available(iOS 15.0, *)
public extension Image {
    static func fromBundle(_ name: String) -> Image {
        Image(uiImage: DiamondImage.image(named: name) ?? UIImage())
    }
}
