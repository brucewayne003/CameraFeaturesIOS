//
//  File.swift
//  DiamondRnMvpoc
//
//  Created by Andres Vinueza on 3/14/23.
//

import SwiftUI
import UIKit

@available(iOS 15.0, *)
public extension Font {
    /// - Parameter size: size of font
    /// - Returns: "Bogle" font (or sytem font as fallback)
    static func bogle(size: CGFloat) -> Font {
        Font(UIFont.bogle(size: size))
    }

    static func bogleMono(size: CGFloat) -> Font {
        Font(UIFont.bogleMono(size: size))
    }
}
