//
//  UIFont+Extension.swift
//  Diamond-sdk
//
//  Created by Adam Bemowski on 6/19/23.
//

import Foundation
import UIKit

/// Convenience getters for custom UIFonts
public extension UIFont {
    static func bogle(size: CGFloat) -> UIFont {
        OsirisUIResourceRegistry.provider?.font(named: "Bogle-Regular", size: size)
            ?? UIFont.systemFont(ofSize: size)
    }

    static func bogleBold(size: CGFloat) -> UIFont {
        OsirisUIResourceRegistry.provider?.font(named: "Bogle-Bold", size: size)
            ?? UIFont.boldSystemFont(ofSize: size)
    }

    static func bogleMono(size: CGFloat) -> UIFont {
        OsirisUIResourceRegistry.provider?.font(named: "BogleMono-Regular", size: size)
            ?? UIFont.monospacedSystemFont(ofSize: size, weight: .regular)
    }
}

public class CustomFonts: NSObject {
  private static let registrationLock = NSLock()
  private static var storedRegistrationOverride: (() -> Void)?

  internal static var fontRegistrationOverride: (() -> Void)? {
    get {
      registrationLock.lock()
      defer { registrationLock.unlock() }
      return storedRegistrationOverride
    }
    set {
      registrationLock.lock()
      let previousOverride = storedRegistrationOverride
      storedRegistrationOverride = newValue
      registrationLock.unlock()
      withExtendedLifetime(previousOverride) {}
    }
  }

  public enum Style: CaseIterable {
    case mono
    case regular
    case bold

    public var value: String {
      switch self {
      case .mono: return "BogleMono-Regular"
      case .regular: return "Bogle-Regular"
      case .bold: return "Bogle-Bold"
      }
    }

    public var font: UIFont {
      switch self {
      case .mono: return .bogleMono(size: 14)
      case .regular: return .bogle(size: 14)
      case .bold: return .bogleBold(size: 14)
      }
    }
  }

  public static var loadFonts: () -> Void {
    get {
      if let registration = fontRegistrationOverride {
        return registration
      }
      OsirisUIResourceRegistry.provider?.registerFonts()
      return {}
    }
    set {
      fontRegistrationOverride = newValue
    }
  }

}
