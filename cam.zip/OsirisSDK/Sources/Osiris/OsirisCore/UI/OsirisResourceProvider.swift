import Foundation
import UIKit

public protocol OsirisResourceProvider {
    func color(named name: String) -> UIColor?
    func image(named name: String) -> UIImage?
    func font(named name: String, size: CGFloat) -> UIFont?

    func registerFonts()
}

public extension OsirisResourceProvider {
    func registerFonts() {}
}


public enum OsirisUIResourceRegistry {
    private static let lock = NSLock()
    private static var storedProvider: OsirisResourceProvider?

    public static var provider: OsirisResourceProvider? {
        get {
            lock.lock()
            defer { lock.unlock() }
            return storedProvider
        }
        set {
            lock.lock()
            let previousProvider = storedProvider
            storedProvider = newValue
            lock.unlock()
            withExtendedLifetime(previousProvider) {}
        }
    }
}
