import CoreText
import Foundation
import Osiris
import UIKit

public final class OsirisDefaultResourceProvider: NSObject, OsirisResourceProvider {
    private let resourceBundle: Bundle? = {
        #if SWIFT_PACKAGE
        return Bundle.module
        #else
        for container in [Bundle(for: OsirisDefaultResourceProvider.self), Bundle.main] {
            if let url = container.url(forResource: "OsirisDefaultResources", withExtension: "bundle"),
               let bundle = Bundle(url: url) {
                return bundle
            }
        }
        return nil
        #endif
    }()

    public override init() {
        super.init()
    }

    public func color(named name: String) -> UIColor? {
        guard let bundle = resourceBundle else { return nil }
        return UIColor(named: name, in: bundle, compatibleWith: nil)
    }

    public func image(named name: String) -> UIImage? {
        guard let bundle = resourceBundle else { return nil }
        return UIImage(named: name, in: bundle, compatibleWith: nil)
    }

    public func font(named name: String, size: CGFloat) -> UIFont? {
        if let font = UIFont(name: name, size: size) {
            return font
        }
        registerFont(named: name)
        return UIFont(name: name, size: size)
    }

    public func registerFonts() {
        ["Bogle-Regular", "Bogle-Bold", "BogleMono-Regular", "BogleMono-Bold"].forEach {
            registerFont(named: $0)
        }
    }

    public var soundURL: URL? {
        resourceBundle?.url(forResource: "scanbeep", withExtension: "wav")
    }

    public func scannerAppearance() -> OsirisScannerAppearance {
        OsirisScannerAppearance(
            detectedReticleColor: color(named: "yellow100") ?? .systemYellow
        )
    }

    public func feedbackConfig() -> OsirisFeedbackConfig {
        OsirisFeedbackConfig(eventFeedback: [
            .standard: Feedback(vibration: .medium, sound: soundURL)
        ])
    }

    public func boundingBoxConfig() -> OsirisBoundingBoxConfig {
        OsirisBoundingBoxConfig(borderColor: color(named: "yellow100") ?? .systemYellow)
    }

    public func installForLegacyUI() {
        registerFonts()
        OsirisUIResourceRegistry.provider = self
    }

    private func registerFont(named name: String) {
        guard UIFont(name: name, size: 12) == nil,
              let bundle = resourceBundle,
              let url = bundle.url(forResource: name, withExtension: "otf")
                ?? bundle.url(forResource: name, withExtension: "otf", subdirectory: "Fonts") else {
            return
        }
        CTFontManagerRegisterFontsForURL(url as CFURL, .process, nil)
    }
}
