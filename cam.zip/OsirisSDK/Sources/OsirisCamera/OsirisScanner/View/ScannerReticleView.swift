//
//  ScannerReticleView.swift
//  OsirisCamera
//
//  Created by Andres Vinueza on 3/26/24.
//

import UIKit

final class ScannerReticleView: UIView {
    // Pull color, corner radius, etc from a config?
    // Common view that'll use an enum to draw different reticle types?
    private var cornerRadius: CGFloat = 1
    private var cornerWidth: CGFloat = 4
    private var cornerLength: CGFloat = 24
    private var cornerLayer: CAShapeLayer!
    var reticleColor: UIColor = .white {
        didSet { cornerLayer?.strokeColor = reticleColor.cgColor }
    }
    var detectedReticleColor: UIColor = .systemYellow

    var didLayoutSubviews: (() -> Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        guard cornerLayer == nil else {
            return
        }
        
        cornerLayer = CAShapeLayer()
        cornerLayer.strokeColor = reticleColor.cgColor
        cornerLayer.fillColor = UIColor.clear.cgColor
        cornerLayer.lineWidth = cornerWidth
        
        let path = UIBezierPath()
        
        // Top left corner
        path.move(to: CGPoint(x: 0, y: cornerLength + cornerRadius))
        path.addLine(to: CGPoint(x: 0, y: cornerRadius))
        path.addArc(withCenter: CGPoint(x: cornerRadius, y: cornerRadius), 
                    radius: cornerRadius,
                    startAngle: CGFloat.pi,
                    endAngle: CGFloat.pi * 3 / 2,
                    clockwise: true)
        path.addLine(to: CGPoint(x: cornerLength + cornerRadius, y: 0))
        
        // Top right corner
        path.move(to: CGPoint(x: bounds.width - cornerLength - cornerRadius, y: 0))
        path.addLine(to: CGPoint(x: bounds.width - cornerRadius, y: 0))
        path.addArc(withCenter: CGPoint(x: bounds.width - cornerRadius, y: cornerRadius), 
                    radius: cornerRadius,
                    startAngle: CGFloat.pi * 3 / 2,
                    endAngle: CGFloat.pi * 2,
                    clockwise: true)
        path.addLine(to: CGPoint(x: bounds.width, y: cornerLength + cornerRadius))

        // Bottom right corner
        path.move(to: CGPoint(x: bounds.width, y: bounds.height - cornerLength - cornerRadius))
        path.addLine(to: CGPoint(x: bounds.width, y: bounds.height - cornerRadius))
        path.addArc(withCenter: CGPoint(x: bounds.width - cornerRadius, y: bounds.height - cornerRadius), 
                    radius: cornerRadius,
                    startAngle: 0,
                    endAngle: CGFloat.pi / 2,
                    clockwise: true)
        path.addLine(to: CGPoint(x: bounds.width - cornerLength - cornerRadius, y: bounds.height))

        // Bottom left corner
        path.move(to: CGPoint(x: cornerLength + cornerRadius, y: bounds.height))
        path.addLine(to: CGPoint(x: cornerRadius, y: bounds.height))
        path.addArc(withCenter: CGPoint(x: cornerRadius, y: bounds.height - cornerRadius), 
                    radius: cornerRadius,
                    startAngle: CGFloat.pi / 2,
                    endAngle: CGFloat.pi,
                    clockwise: true)
        path.addLine(to: CGPoint(x: 0, y: bounds.height - cornerLength - cornerRadius))
        
        cornerLayer.path = path.cgPath
        
        layer.addSublayer(cornerLayer)
        
        didLayoutSubviews?()
    }
    
    // MARK: Private
    
    private func setupView() {
        backgroundColor = .clear
        isUserInteractionEnabled = false
        translatesAutoresizingMaskIntoConstraints = false
    }
    
    // MARK: Public
    
    func toggleReticleColor() {
        let animation = CABasicAnimation(keyPath: "strokeColor")
        animation.toValue = detectedReticleColor.cgColor
        animation.duration = 0.25
        animation.autoreverses = true
        animation.repeatCount = 1
        cornerLayer?.add(animation, forKey: nil)
    }
}
