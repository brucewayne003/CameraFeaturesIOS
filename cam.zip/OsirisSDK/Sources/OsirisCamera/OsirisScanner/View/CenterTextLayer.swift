//
//  CenterTextLayer.swift
//  OsirisBarcode
//
//  Created by Ahmed Bekhit on 11/8/24.
//

import Foundation
import UIKit

public class CenterTextLayer: CATextLayer {
    
    public override init() {
        super.init()
    }
    
    public override init(layer: Any) {
        super.init(layer: layer)
    }
    
    public required init(coder aDecoder: NSCoder) {
        super.init(layer: aDecoder)
    }
    
    public override func draw(in context: CGContext) {
        let height = self.bounds.size.height
        let fontSize = self.fontSize
        let yDiff = (height-fontSize)/2 - fontSize/10

        context.saveGState()
        context.translateBy(x: 0, y: yDiff) // Use -yDiff when in non-flipped coordinates (like macOS's default)
        super.draw(in: context)
        context.restoreGState()
    }
}

