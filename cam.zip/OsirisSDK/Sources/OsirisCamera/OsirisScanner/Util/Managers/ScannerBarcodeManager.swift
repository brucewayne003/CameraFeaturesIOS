//
//  ScannerBarcodeManager.swift
//  OsirisCamera
//
//  Created by Kyle McGinnis on 3/4/24.
//

import AudioToolbox
import AVFAudio
import Osiris
import OsirisBarcode
import UIKit

class ScannerBarcodeManager {
    
    // MARK: Properties
    @Published var multiScanEnabled: Bool = false
    @Published var barcodeBoundingBoxes: [BarcodeBoundingBox] = []
    @Published var boundingBoxes: [CGRect] = []
    @Published var barcodes: [Barcode] = []
    @Published var feedbackConfig: OsirisFeedbackConfig?
    var audioPlayer: AVAudioPlayer?
    
    // MARK - Private Properties
    private lazy var customHapticManager = HapticManager()

    private var emptyBoundingBoxesCount = 0
    private var shouldRemoveAllBoundingBoxes: Bool {
        emptyBoundingBoxesCount >= 6
    }
    
    // MARK: Internal API
    
    internal func addBarcodeWithFeedback(_ barcode: Barcode) {
        addBarcodesWithFeedback([barcode])
    }
    
    internal func addBarcodesWithFeedback(_ barcodes: [Barcode]) {
        self.barcodes = []
        for barcode in barcodes {
            self.barcodes.append(barcode)
        }
        didUpdateBarcodes()
        Logging.log("Barcodes \(barcodes.count),: \(barcodes.map { $0.value })")
    }
    
    internal func removeBarcodes() {
        removeBoundingBoxes()
        barcodes.removeAll()
    }
        
    internal func removeBoundingBoxes() {
        barcodeBoundingBoxes.removeAll()
    }
    
    internal func removeBoundingBoxesIfNeeded(for barcodes: [Barcode]) {
        if barcodes.isEmpty {
            emptyBoundingBoxesCount += 1
        } else {
            emptyBoundingBoxesCount = 0
        }
        
        guard shouldRemoveAllBoundingBoxes else { return }
        barcodeBoundingBoxes.removeAll()
    }
    
    // MARK: Private Playback Helpers
    
    private func didUpdateBarcodes() {
        self.barcodeBoundingBoxes = barcodes.compactMap {
            if let boundingBox = $0.boundingBoxInCameraPreview {
                return ($0, boundingBox)
            }
            
            return nil
        }
        
        self.boundingBoxes = barcodeBoundingBoxes.map { $0.boundingBox }
        
        guard !barcodes.isEmpty else { return }
        Task {
            guard !multiScanEnabled else {
                // Do not play feedback (neither sound nor vibration)  when multi-scan is enabled
                return
            }
            
            let haptic = getFeedback()?.vibration
            let generator: UIImpactFeedbackGenerator?
            
            if case let .custom(intensity, sharpness, duration) = haptic {
                generator = nil
                customHapticManager.playCustomVibration(intensity: intensity, sharpness: sharpness, duration: duration)
            } else {
                generator = await prepareFeedback(haptic: haptic)
            }
                
            await performFeedback(withGenerator: generator)
        }
    }
    
    func getFeedback() -> Feedback? {
        /// Take feedback from success event but fallback to standard if success doesn't exist.  
        let feedback = feedbackConfig?.getFeedback(forEvent: .success) ?? feedbackConfig?.getFeedback(forEvent: .standard)
        return feedback?.enabled == true ? feedback : nil
    }
    
    private func prepareFeedback(haptic: VibrationType?) async -> UIImpactFeedbackGenerator? {
        guard !multiScanEnabled, let haptic = haptic else {
            return nil
        }
        
        switch haptic {
        case .light, .medium, .heavy:
            let feedbackGenerator = await UIImpactFeedbackGenerator(style: haptic.feedbackStyle)
            await feedbackGenerator.prepare()
            return feedbackGenerator
        case .custom:
            return nil
        }
    }
    
    @MainActor
    private func performFeedback(withGenerator generator: UIImpactFeedbackGenerator?) async {
        if let url = getFeedback()?.sound {
            playAudio(fromURL: url)
        }
        generator?.impactOccurred()
    }
    
    func playAudio(fromURL url: URL) {
        guard !multiScanEnabled else {
            return // Do not play sound when on multi-scan
        }
        
        Logging.log("Playing \(url)")
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.ambient, options: [.mixWithOthers])
            try session.setActive(true)
            self.audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.prepareToPlay()
            audioPlayer?.volume = 1.0
            audioPlayer?.play()
        } catch let error as NSError {
            self.audioPlayer = nil
            Logging.log(error.localizedDescription, logLevel: .warning)
        } catch {
            Logging.log("AVAudioPlayer init failed", logLevel: .warning)
        }
    }
    
    internal func reset() {
        // Add any reset logic needed for barcode manager
    }
    
}
