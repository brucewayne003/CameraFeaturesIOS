import Foundation
import Osiris

extension UserDefaults {
    private static let selectedScanArea = "diamond.selectedScanArea"
    
    public dynamic var selectedScanArea: ScanArea {
        get {
            if let rawString = string(forKey: UserDefaults.selectedScanArea) {
                return ScanArea(rawValue: rawString) ?? .center
            }
            
            return .center
        }

        set {
            set(newValue.rawValue, forKey: UserDefaults.selectedScanArea)
        }
    }
    
}
