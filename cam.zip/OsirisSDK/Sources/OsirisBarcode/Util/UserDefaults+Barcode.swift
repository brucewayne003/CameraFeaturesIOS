//
//  UserDefaults+Barcode.swift
//
//
//  Created by Bryan Norden on 11/17/23.
//

import Foundation
import Osiris

extension UserDefaults {
    private static let currentDecoderOptionsKey = "diamond.barcodeDecoderOptions"
    
    public var currentDecoderOptions: BarcodeDecoderOptions {
        get {
            do {
                let options = try getCodable(forKey: UserDefaults.currentDecoderOptionsKey, castTo: BarcodeDecoderOptions.self)
                return options
            } catch {
                return BarcodeDecoderOptions.defaultOptions
            }
        }

        set {
            try? setCodable(newValue, forKey: UserDefaults.currentDecoderOptionsKey)
        }
    }
    
    private static let dataCaptureSession = "diamond.dataCaptureSession"
    
    public var dataCaptureSession: DataCaptureSession {
        get {
            do {
                let session = try getCodable(forKey: UserDefaults.dataCaptureSession, castTo: DataCaptureSession.self)
                return session
            } catch {
                return DataCaptureSession.defaultSession
            }
        }

        set {
            try? setCodable(newValue, forKey: UserDefaults.dataCaptureSession)
        }
    }
    
    private static let scanActionTypeKey = "diamond.scanActionType"
    
    public var scanActionType: ScanActionType {
        get {
            do {
                return try getCodable(forKey: UserDefaults.scanActionTypeKey, castTo: ScanActionType.self)
            } catch {
                return .continuous
            }
        }
        set {
            try? setCodable(newValue, forKey: UserDefaults.scanActionTypeKey)
        }
    }
    
    private static let scanThreshold = "diamond.scanThreshold"

    @objc public dynamic var scanThreshold: String {
        get {
            string(forKey: UserDefaults.scanThreshold) ?? ""
        }
        
        set {
            set(newValue, forKey: UserDefaults.scanThreshold)
        }
    }
    
    private static let allowBenchmarkingKey = "diamond.allowBenchmarking"
    
    @objc public dynamic var allowBenchmarking: Bool {
        get {
            bool(forKey: UserDefaults.allowBenchmarkingKey)
        }

        set {
            set(newValue, forKey: UserDefaults.allowBenchmarkingKey)
        }
    }
    
    private static let isGCSBenchmarkingOutputEnabledKey = "diamond.GCSBenchmarkingOutputEnabled"
    
    @objc public dynamic var isGCSBenchmarkingOutputEnabled: Bool {
        get {
            bool(forKey: UserDefaults.isGCSBenchmarkingOutputEnabledKey)
        }

        set {
            set(newValue, forKey: UserDefaults.isGCSBenchmarkingOutputEnabledKey)
        }
    }
    
    private static let isDiskBenchmarkingOutputEnabledKey = "diamond.diskBenchmarkingOutputEnabled"
    
    @objc public dynamic var isDiskBenchmarkingOutputEnabled: Bool {
        get {
            bool(forKey: UserDefaults.isDiskBenchmarkingOutputEnabledKey)
        }

        set {
            set(newValue, forKey: UserDefaults.isDiskBenchmarkingOutputEnabledKey)
        }
    }
    
    private static let isDataCaptureEnabled = "diamond.isDataCaptureEnabled"
    
    @objc public dynamic var isDataCaptureEnabled: Bool {
        get {
            bool(forKey: UserDefaults.isDataCaptureEnabled)
        }

        set {
            set(newValue, forKey: UserDefaults.isDataCaptureEnabled)
        }
    }
    
}
