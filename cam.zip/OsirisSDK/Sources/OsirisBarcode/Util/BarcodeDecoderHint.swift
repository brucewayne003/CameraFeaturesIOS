//
//  BarcodeDecoderHint.swift
//  Osiris
//
//  Created by Bryan Norden on 11/30/23.
//

import Foundation
import Osiris
import ZXingCpp

public enum BarcodeDecoderHint: String, Codable, CaseIterable, Equatable, Hashable {
    case tryHarder
    case tryRotate
    case tryDiagonal
    case tryInvert
    case tryDownscale
    case tryErosion
    case tryRebalance
    case tryCode39ExtendedMode
    case validateCode39CheckSum
    case validateITFCheckSum
    case tryCLAHE
    case tryCLAHEAll
    case enableDeblur
    case enableLaplacianVariance
    case enableObjectDetection
    case enableParallelPyramid
    case enableAdaptiveFiltering
    case serialSmallAngleRotation
    case parallelSmallAngleRotation
    case enableTemplateMatching

    // MARK: Properties
    public static var defaultHints: [BarcodeDecoderHint] {
        // ZXing::DecodeHints default enabled hints from v2.9.1
        return [
            .tryHarder,
            .tryRotate,
            .tryDiagonal,
            .tryInvert,
            .tryDownscale,
            .tryCLAHE,
            .validateITFCheckSum,
            .enableLaplacianVariance,
            .enableAdaptiveFiltering
        ]
    }
    
    // MARK: Public API
    
    public static func getSmallAngleRotation(serialSmallAngleRotation: Bool,
                                             parallelSmallAngleRotation: Bool) -> SmallAngleRotation {
        if parallelSmallAngleRotation {
            return .ZXIPARALLEL_SMALL_ANGLE_ROTATION
        }
        
        if serialSmallAngleRotation {
            return .ZXISERIAL_SMALL_ANGLE_ROTATION
        }

        return .ZXINO_SMALL_ANGLE_ROTATION
    }
    
    public static func getTryCLAHEType(tryCLAHEEnabled: Bool, tryCLAHEALLEnabled: Bool) -> CLAHEOptions {
        if tryCLAHEALLEnabled {
            return .ZXICLAHE_ALL
        }
        if tryCLAHEEnabled {
            return .ZXICLAHE_ONFAIL
        }
        return .ZXICLAHE_NONE
    }
    
    public static func hints(forHintGroup group: HintGroup) -> [BarcodeDecoderHint] {
        var result: [BarcodeDecoderHint]
        switch group {
        case .basic:
            result = defaultHints
        case .intermediate:
            result = hints(forHintGroup: .basic) + [.tryDiagonal]
        case .advanced:
            result = hints(forHintGroup: .intermediate) + [.tryErosion, .tryRebalance, .tryCode39ExtendedMode, .enableDeblur, .enableObjectDetection]
        case .all:
            result = hints(forHintGroup: .advanced) + [.validateCode39CheckSum, .validateITFCheckSum, .tryCLAHEAll]
        case .none:
            return []
        }
        return Array(Set(result)).sorted { $0.rawValue < $1.rawValue }
    }
    
}

extension BarcodeDecoderHint: Comparable {
    
    public static func < (lhs: BarcodeDecoderHint, rhs: BarcodeDecoderHint) -> Bool {
        lhs.rawValue < rhs.rawValue
    }
    
}
