// swift-tools-version: 5.8
// The swift-tools-version declares the minimum version of Swift required to build this package.

import PackageDescription

let package = Package(
    name: "Osiris",
    platforms: [
        .iOS("15.1")
    ],
    products: [
        .library(
            name: "Osiris",
            targets: ["Osiris"]),
        .library(
            name: "OsirisDefaultResources",
            targets: ["OsirisDefaultResources"]),
        .library(
            name: "OsirisBarcode",
            targets: ["OsirisBarcode"]),
        .library(
            name: "OsirisCamera",
            targets: ["OsirisCamera"]),
        .library(
            name: "OsirisDigitalLocks",
            targets: ["OsirisDigitalLocks"]),
        .library(
            name: "BluetoothPlatform",
            targets: ["BluetoothPlatform"])
    ],
//    dependencies: [
//        .package(url: "git@gecgithub01.walmart.com:Project-Diamond/zxing-cpp.git", exact: "2.14.0")
//    ],
    targets: [
        // Targets are the basic building blocks of a package, defining a module or a test suite.
        // Targets can depend on other targets in this package and products from dependencies.
//        .binaryTarget(
//            name: "ZXingCpp",
//            path: "Frameworks/ZXingCPP.xcframework"
//        ),
        .binaryTarget(
            name: "ZXingCpp",
            url: "https://generic.ci.artifacts.walmart.com/artifactory/project-diamond-generic/zxing-cpp/xcframework-iOS-2026.09.17.3.zip",
            checksum: "7338b0d5fa9cf70ef5aee4584040d21b527916c060f7b8c0d2b7575186ba0f9a"
        ),
        .target(
            name: "Osiris",
            resources: [.copy("PrivacyInfo.xcprivacy")]
        ),
        .target(
            name: "OsirisDefaultResources",
            dependencies: ["Osiris"],
            resources: [.process("Resources")]
        ),
        .target(
            name: "OsirisBarcode",
            dependencies: ["Osiris", "ZXingCpp"],
            resources: [.copy("PrivacyInfo.xcprivacy")]
        ),
        .target(
            name: "OsirisCamera",
            dependencies: ["Osiris", "OsirisBarcode"],
            resources: [.copy("PrivacyInfo.xcprivacy")]
        ),
        .target(
            name: "BluetoothPlatform"
        ),
        .target(
            name: "OsirisDigitalLocks",
            dependencies: ["Osiris"]
        ),
        .testTarget(
            name: "OsirisHeadlessTests",
            dependencies: ["Osiris", "OsirisBarcode"],
            resources: [.copy("Fixtures")],
            linkerSettings: [.linkedLibrary("z")]
        ),
        .testTarget(
            name: "OsirisDefaultResourcesTests",
            dependencies: ["Osiris", "OsirisDefaultResources"]
        ),
        .testTarget(
            name: "OsirisTests",

            dependencies: ["Osiris", "OsirisBarcode", "OsirisDigitalLocks", "OsirisCamera", "BluetoothPlatform"],
            resources: [
                .copy("SampleBarcodes/code128-1"),
                .copy("SampleBarcodes/code128-2"),
                .copy("SampleBarcodes/code128-3"),
                .copy("SampleBarcodes/code39-1"),
                .copy("SampleBarcodes/code39-2"),
                .copy("SampleBarcodes/code39-3"),
                .copy("SampleBarcodes/code93-1"),
                .copy("SampleBarcodes/datamatrix-1"),
                .copy("SampleBarcodes/datamatrix-2"),
                .copy("SampleBarcodes/datamatrix-3"),
                .copy("SampleBarcodes/datamatrix-4"),
                .copy("SampleBarcodes/ean13-1"),
                .copy("SampleBarcodes/ean13-2"),
                .copy("SampleBarcodes/ean13-3"),
                .copy("SampleBarcodes/ean13-4"),
                .copy("SampleBarcodes/ean13-extension-1"),
                .copy("SampleBarcodes/ean8-1"),
                .copy("SampleBarcodes/qrcode-1"),
                .copy("SampleBarcodes/qrcode-2"),
                .copy("SampleBarcodes/qrcode-3"),
                .copy("SampleBarcodes/qrcode-4"),
                .copy("SampleBarcodes/qrcode-5"),
                .copy("SampleBarcodes/qrcode-6"),
                .copy("SampleBarcodes/rss14-1"),
                .copy("SampleBarcodes/rss14-2"),
                .copy("SampleBarcodes/rss14-3"),
                .copy("SampleBarcodes/rss14-4"),
                .copy("SampleBarcodes/rss14-5"),
                .copy("SampleBarcodes/rssexpanded-1"),
                .copy("SampleBarcodes/rssexpanded-2"),
                .copy("SampleBarcodes/rssexpanded-3"),
                .copy("SampleBarcodes/rssexpandedstacked-1"),
                .copy("SampleBarcodes/rssexpandedstacked-2"),
                .copy("SampleBarcodes/upca-1"),
                .copy("SampleBarcodes/upca-2"),
                .copy("SampleBarcodes/upca-3"),
                .copy("SampleBarcodes/upca-4"),
                .copy("SampleBarcodes/upca-5"),
                .copy("SampleBarcodes/upca-extension-1"),
                .copy("SampleBarcodes/upce-1"),
                .copy("SampleBarcodes/upce-2"),
                .copy("SampleBarcodes/upce-3")
            ],
            linkerSettings: [
                .linkedLibrary("z") // Add zlib linking here
            ]
        ),
        .testTarget(
            name: "OsirisContractTests",
            dependencies: ["Osiris", "OsirisBarcode", "OsirisDigitalLocks", "OsirisCamera"],
            linkerSettings: [
                .linkedLibrary("z") // Add zlib linking here
            ]
        )
    ]
)
