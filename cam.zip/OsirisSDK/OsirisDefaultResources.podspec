Pod::Spec.new do |spec|
  spec.name         = "OsirisDefaultResources"
  spec.version      = "2026.10.19.7"
  spec.summary      = "Optional default fonts, colors, images, and scan sound for Osiris."
  spec.description  = "Default presentation resources that applications may opt into when using Osiris."
  spec.homepage     = "https://gecgithub01.walmart.com/Project-Diamond/osiris-ios"
  spec.license      = { :type => 'MIT', :file => 'LICENSE' }
  spec.author       = { 'Diamond Engineering' => 'https://confluence.walmart.com/display/BDP' }
  spec.platform = :ios, '15.1'
  spec.ios.deployment_target = '15.1'
  spec.swift_versions = ['5.0']
  spec.source = {
    :git => 'git@gecgithub01.walmart.com:Project-Diamond/osiris-ios.git',
    :tag => spec.version.to_s
  }

  spec.requires_arc = true
  spec.frameworks = ["UIKit", "CoreText"]
  spec.source_files = "Sources/OsirisDefaultResources/**/*.swift"
  spec.resource_bundles = {
    'OsirisDefaultResources' => [
        'Sources/OsirisDefaultResources/Resources/Fonts/*.otf',
        'Sources/OsirisDefaultResources/Resources/Assets/*.xcassets',
        'Sources/OsirisDefaultResources/Resources/*.wav'
    ]
  }
  spec.dependency 'Osiris', spec.version.to_s
end
