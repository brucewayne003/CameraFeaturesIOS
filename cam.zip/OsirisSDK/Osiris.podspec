Pod::Spec.new do |spec|
  spec.name         = "Osiris"
  spec.version      = "2026.10.19.7"
  spec.summary      = "A short description of Osiris."
  spec.description  = "Long description of Osiris Barcode scanning SDK"
  spec.homepage     = "https://gecgithub01.walmart.com/Project-Diamond/osiris-ios"
  spec.license      = { :type => 'MIT', :file => 'LICENSE' }
  spec.author       = { 'Diamond Engineering' => 'https://confluence.walmart.com/display/BDP' }
  spec.platform = :ios, '15.1'
  spec.ios.deployment_target = '15.1'
  spec.swift_versions = ['5.0']
  spec.source = {
    :git => 'git@gecgithub01.walmart.com:Project-Diamond/osiris-ios.git',
    :tag => spec.version.to_s,
    :submodules => true
  }
  
  spec.resource_bundles = {
    'OsirisPrivacy' => ['PrivacyInfo.xcprivacy']
  }

  spec.requires_arc = true
  spec.frameworks = ["CoreGraphics", "CoreImage", "CoreVideo", "AVFoundation", "UIKit", "Combine", "Vision"]
  
  spec.source_files = [ 
    'Sources/Osiris/**/*.swift',
  ]
    
end
