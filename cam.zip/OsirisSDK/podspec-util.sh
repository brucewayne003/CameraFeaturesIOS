#!/bin/zsh

# List of podspec files
spec_names=("Osiris" "OsirisDefaultResources" "OsirisBarcode" "BluetoothPlatform" "OsirisCamera" "OsirisDigitalLocks")

# BluetoothPlatform is versioned (and deployment-target'd) independently - excluded from the
# shared deployment target bump below.
deployment_target_spec_names=("Osiris" "OsirisDefaultResources" "OsirisBarcode" "OsirisCamera" "OsirisDigitalLocks")
build_config_file="build-config.env"
build_config_key_deployment_target="IOS_DEPLOYMENT_TARGET"
build_config_key_artifactory_base="ZXING_ARTIFACTORY_BASE_URL"
build_config_key_pod_repo="PRIVATE_POD_REPO"
osiris_build_info_file="Sources/Osiris/OsirisBuildInfo.swift"

# Reads a KEY=VALUE pair out of build-config.env, e.g. `read_build_config IOS_DEPLOYMENT_TARGET`
read_build_config() {
    local key="$1"
    if [ ! -f "$build_config_file" ]; then
        echo "Error: ${build_config_file} not found" >&2
        exit 1
    fi
    local value
    value=$(grep -E "^${key}=" "$build_config_file" | head -1 | cut -d '=' -f2-)
    if [ -z "$value" ]; then
        echo "Error: ${key} not found in ${build_config_file}" >&2
        exit 1
    fi
    echo "$value" | tr -d '[:space:]'
}

# Command line arguments
version=""
versionFlag=false
zxingVersion=""
zxingFlag=false
deploymentTarget=""
deploymentTargetFlag=false
packageSwiftZxingVersion=""
packageSwiftZxingFlag=false
lintFlag=false
lintSpec=""
pushFlag=false

for arg in "$@"
do
    case "$arg" in
        --lint)
            lintFlag=true
            shift
            if [ ! -z "$1" ]; then
                lintSpec="$1"
                shift
            else
                echo "Error --lint flag requires podspec name, ie OsirisCore.podspec"
                exit 1
            fi
            ;;
        --push)
            pushFlag=true
            ;;
        --version)
            versionFlag=true
            shift
            if [ ! -z "$1" ]; then
                version="$1"
                shift
            else
                echo "Error --version flag requires a version number"
                exit 1
            fi
            ;;
        --zxing)
            zxingFlag=true
            shift
            if [ ! -z "$1" ]; then
                zxingVersion="$1"
                shift
            else
                echo "Error --zxing flag requires a version number"
                exit 1
            fi
            ;;
        --deployment-target)
            deploymentTargetFlag=true
            shift
            # Value is optional - falls back to build-config.env's IOS_DEPLOYMENT_TARGET when
            # omitted, so CI/scripts can bump everything from that single file without a literal arg.
            if [ ! -z "$1" ] && [[ "$1" != --* ]]; then
                deploymentTarget="$1"
                shift
            fi
            ;;
        --package-swift-zxing)
            packageSwiftZxingFlag=true
            shift
            # No config-file fallback here, deliberately - whether Package.swift should point
            # at a given zxing version is a per-release call (see the ML Package.swift/CocoaPods
            # disconnect rule), not a static default.
            if [ ! -z "$1" ]; then
                packageSwiftZxingVersion="$1"
                shift
            else
                echo "Error --package-swift-zxing flag requires a zxing-cpp version number"
                exit 1
            fi
            ;;

        *)
            ;;
    esac
done

if [ "$versionFlag" = false ] && [ "$zxingFlag" = false ] && [ "$deploymentTargetFlag" = false ] && [ "$packageSwiftZxingFlag" = false ] && [ "$lintFlag" = false ] && [ "$pushFlag" = false ]; then
    echo "Usage $0 --version 0.2.9 (updates all podspecs to 0.2.9 + OsirisBuildInfo.swift's osirisPodVersion)"
    echo "Usage $0 --zxing 2.12.2 (updates all podspecs zxing dependency + OsirisBuildInfo.swift's zxingCppVersion to 2.12.2)"
    echo "Usage $0 --deployment-target [15.1] (updates Osiris/OsirisDefaultResources/OsirisBarcode/OsirisCamera/OsirisDigitalLocks podspecs + Package.swift; reads ${build_config_key_deployment_target} from ${build_config_file} when the value is omitted; BluetoothPlatform is excluded, it's versioned independently)"
    echo "Usage $0 --package-swift-zxing 2.12.2 (downloads the xcframework zip, computes its checksum, and updates Package.swift's url+checksum - non-ML releases only; see the ML Package.swift/CocoaPods disconnect rule before using this for ML)"
    echo "Usage $0 --lint OsirisCore.podspec (runs pod lib lint on OsirisCore)"
    echo "Usage $0 --push (runs pod lib lint & repo push for all podspecs)"
fi

# Supported methods
update_versions() {
    for name in "${spec_names[@]}"; do
        podspec="${name}.podspec"
        # Updating podspec version
        sed -i.bak "s/\(spec.version *= *\).*/\1\"$version\"/" $podspec
        rm ${podspec}.bak
        echo "Updated ${podspec} to ${version}"
    done

    if [ -f "$osiris_build_info_file" ]; then
        sed -i.bak "s/\(osirisPodVersion = \).*/\1\"$version\"/" "$osiris_build_info_file"
        rm "${osiris_build_info_file}.bak"
        echo "Updated ${osiris_build_info_file} osirisPodVersion to ${version}"
    fi

    echo
    exit 0
}

update_zxing_versions() {
    for name in "${spec_names[@]}"; do
        podspec="${name}.podspec"
        # Updating podspec version
        sed -i.bak "s/\(spec.dependency 'zxing-cpp',\).*/\1 \'$zxingVersion\'/g" $podspec
        rm ${podspec}.bak
        echo "Updated ${podspec} to zxing ${zxingVersion}"
    done

    if [ -f "$osiris_build_info_file" ]; then
        sed -i.bak "s/\(zxingCppVersion = \).*/\1\"$zxingVersion\"/" "$osiris_build_info_file"
        rm "${osiris_build_info_file}.bak"
        echo "Updated ${osiris_build_info_file} zxingCppVersion to ${zxingVersion}"
    fi

    echo
    exit 0
}

update_deployment_target() {
    local target="$deploymentTarget"
    if [ -z "$target" ]; then
        target=$(read_build_config "$build_config_key_deployment_target")
    fi

    for name in "${deployment_target_spec_names[@]}"; do
        podspec="${name}.podspec"
        sed -i.bak "s/\(spec.platform *= *:ios, *\).*/\1'$target'/" $podspec
        sed -i.bak "s/\(spec.ios.deployment_target *= *\).*/\1'$target'/" $podspec
        rm ${podspec}.bak
        echo "Updated ${podspec} deployment target to ${target}"
    done

    # Package.swift's platforms entry can be either the .vNN enum form or a prior
    # custom string form (.iOS("NN.N")) - replace whichever is present.
    sed -i.bak -E "s/\.iOS\((\.v[0-9_]+|\"[0-9.]+\")\)/.iOS(\"$target\")/" Package.swift
    rm Package.swift.bak
    echo "Updated Package.swift iOS platform to ${target}"

    echo
    exit 0
}

update_package_swift_zxing() {
    local target_version="$packageSwiftZxingVersion"
    local base_url
    base_url=$(read_build_config "$build_config_key_artifactory_base")
    local zip_url="${base_url}/xcframework-iOS-${target_version}.zip"
    local tmp_zip="/tmp/zxing-${target_version}.zip"

    echo "Downloading ${zip_url}..."
    local http_code
    # No explicit --proxy: curl already honors HTTPS_PROXY/https_proxy/HTTP_PROXY/http_proxy from
    # the environment, so this works unmodified on machines with or without a corporate proxy.
    http_code=$(curl -sS -o "$tmp_zip" "$zip_url" -w "%{http_code}")
    echo "HTTP ${http_code}, size $(wc -c < "$tmp_zip" | tr -d '[:space:]') bytes"
    if [ "$http_code" != "200" ]; then
        echo "Error: download failed with HTTP ${http_code} for ${zip_url} (not a 200 - refusing to checksum an error page)"
        exit 1
    fi
    if [ ! -s "$tmp_zip" ]; then
        echo "Error: download produced an empty file for ${zip_url}"
        exit 1
    fi

    local checksum
    checksum=$(shasum -a 256 "$tmp_zip" | awk '{print $1}')
    echo "Computed checksum: ${checksum}"

    sed -i.bak -E "s#url: \"[^\"]*xcframework-iOS-[0-9.]+\.zip\"#url: \"${zip_url}\"#" Package.swift
    sed -i.bak -E "s/checksum: \"[a-f0-9]+\"/checksum: \"${checksum}\"/" Package.swift
    rm Package.swift.bak
    echo "Updated Package.swift zxing binary target to ${target_version}"

    echo
    exit 0
}

pod_lint() {
    local podspec="$1"
    echo "Processing ${podspec}..."
    lint_result=$(pod lib lint ${podspec} --sources='git@gecgithub01.walmart.com:Project-Diamond/cocoapods-specs.git' --allow-warnings > /dev/null 2>&1; echo $?)
    if [[ $lint_result -eq 0 ]]; then
        echo "${podspec} lint PASSED"
    else
        echo "pod lib lint FAILED"
        exit 1
    fi
    echo
    exit 0
}

pod_push() {
    local podspec="$1"
    local pod_repo
    pod_repo=$(read_build_config "$build_config_key_pod_repo")
    push_result=$(pod repo push ${pod_repo} ${podspec} --verbose --allow-warnings --skip-import-validation --use-libraries > /dev/null 2>&1; echo $?)
    if [[ $push_result -eq 0 ]]; then
        echo "${podspec} repo push PASSED"
    else
        echo "${podspec} repo push FAILED"
        exit 1
    fi
}

pod_lint_push() {
    for name in "${spec_names[@]}"; do
        podspec="${name}.podspec"
        echo "Processing ${podspec}..."
        pod_push $podspec
    done
    echo
    exit 0
}

# Process commands
if [ "$versionFlag" = true ]; then
    update_versions
fi

if [ "$zxingFlag" = true ]; then
    update_zxing_versions
fi

if [ "$deploymentTargetFlag" = true ]; then
    update_deployment_target
fi

if [ "$packageSwiftZxingFlag" = true ]; then
    update_package_swift_zxing
fi

if [ "$lintFlag" = true ]; then
    pod_lint $lintSpec
fi

if [ "$pushFlag" = true ]; then
    pod_lint_push
fi
