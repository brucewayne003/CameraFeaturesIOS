import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import tempfile

OPERATIONS = json.loads(r'''[
  {
    "step": 1,
    "repo": "SDK",
    "path": "Osiris.podspec",
    "old": null,
    "sha256": "eed673fe2b3780b6a2c0a85531f57936423c0099e5a66388747af4727acbd10e",
    "mode": 420
  },
  {
    "step": 2,
    "repo": "SDK",
    "path": "OsirisDefaultResources.podspec",
    "old": null,
    "sha256": "2f3fb59cc91cc24821f74e9e6a4a4e4735175e57e11fc5e45da7d64096749863",
    "mode": 420
  },
  {
    "step": 3,
    "repo": "SDK",
    "path": "Package.swift",
    "old": null,
    "sha256": "a2410d77f33b0de7df23cbe7136a6689b6a240dbe2a0793bbde44a171484c5cb",
    "mode": 420
  },
  {
    "step": 4,
    "repo": "SDK",
    "path": "Sources/Osiris/Integration/Config/OsirisBoundingBoxConfig.swift",
    "old": null,
    "sha256": "f29167a048810a7fb7c89057b684e0092addf70c85bd30307581e5818f5ae5d2",
    "mode": 420
  },
  {
    "step": 5,
    "repo": "SDK",
    "path": "Sources/Osiris/Integration/Config/OsirisConfig.swift",
    "old": null,
    "sha256": "152d5fdb91569f80a960226732abced4098501accc4744052ad4c7ecc126cb9e",
    "mode": 420
  },
  {
    "step": 6,
    "repo": "SDK",
    "path": "Sources/Osiris/Integration/Config/OsirisFeedbackConfig.swift",
    "old": null,
    "sha256": "420434d98bed576a5ee261ed7021909f1e931bf3574d19576eaee63567ee61e4",
    "mode": 420
  },
  {
    "step": 7,
    "repo": "SDK",
    "path": "Sources/Osiris/Integration/Config/OsirisScannerAppearance.swift",
    "old": null,
    "sha256": "3aeeff9fff841e00d28fc76376592798a042e8595a6d90420310d294fbea3f9d",
    "mode": 420
  },
  {
    "step": 8,
    "repo": "SDK",
    "path": "Sources/Osiris/OsirisCore/UI/Extensions/Color+Extension.swift",
    "old": null,
    "sha256": "0185eb15cd6bea169d2615b6f9911cd14b9b0da8eaf76484c6a403a1d93c96a4",
    "mode": 420
  },
  {
    "step": 9,
    "repo": "SDK",
    "path": "Sources/Osiris/OsirisCore/UI/Extensions/Font+Extension.swift",
    "old": null,
    "sha256": "7e626dafbc3e5786e28c64d6f94a5941e660a23a1ce25616183f3e0fefe226a6",
    "mode": 420
  },
  {
    "step": 10,
    "repo": "SDK",
    "path": "Sources/Osiris/OsirisCore/UI/Extensions/Image+Extension.swift",
    "old": null,
    "sha256": "154d44e3dbba093ed73c9edfb75d0ad93a334700b328e9842bae97e5ad1ff3e2",
    "mode": 420
  },
  {
    "step": 11,
    "repo": "SDK",
    "path": "Sources/Osiris/OsirisCore/UI/Extensions/UIColor+Extension.swift",
    "old": null,
    "sha256": "ea13df987e717e9c937c92518ea08854304e34964ce17276e2c4fd7e814a62a3",
    "mode": 420
  },
  {
    "step": 12,
    "repo": "SDK",
    "path": "Sources/Osiris/OsirisCore/UI/Extensions/UIFont+Extension.swift",
    "old": null,
    "sha256": "bd1c6bc88a61f447cc5270d51901eab3552534b294f272d0ffabbbc935c48766",
    "mode": 420
  },
  {
    "step": 13,
    "repo": "SDK",
    "path": "Sources/Osiris/OsirisCore/UI/Extensions/UIImage+Extension.swift",
    "old": null,
    "sha256": "6e68adde7d124354b7f6f20b757a7c37ce5a0da7c978b4a39fa0178615c371be",
    "mode": 420
  },
  {
    "step": 14,
    "repo": "SDK",
    "path": "Sources/Osiris/OsirisCore/UI/OsirisResourceProvider.swift",
    "old": null,
    "sha256": "05ab97bd06416bfd4e1c7d1f8b5e5615aef51003d0223d41bf242492b1fc508b",
    "mode": 420
  },
  {
    "step": 15,
    "repo": "SDK",
    "path": "Sources/OsirisBarcode/Util/BarcodeDecoderHint.swift",
    "old": null,
    "sha256": "0d449b36033b9e0b4565bfdd21040eca80ce8563cd1dbaa7aece834e4dcaf7ca",
    "mode": 420
  },
  {
    "step": 16,
    "repo": "SDK",
    "path": "Sources/OsirisBarcode/Util/UserDefaults+Barcode.swift",
    "old": null,
    "sha256": "f1a6d98b8f8fc39fe37af591b0a7914b892160f5922661c4d26ada0254409028",
    "mode": 420
  },
  {
    "step": 17,
    "repo": "SDK",
    "path": "Sources/OsirisCamera/OsirisScanner/Controller/OsirisScannerViewController.swift",
    "old": null,
    "sha256": "3de80e7570f8e5f8d268ea181d7689c00273a503430e26606ef44d796a390e11",
    "mode": 420
  },
  {
    "step": 18,
    "repo": "SDK",
    "path": "Sources/OsirisCamera/OsirisScanner/Util/Managers/ScannerBarcodeManager.swift",
    "old": null,
    "sha256": "6dda842cfc20e2f5c110c0a1b8eb19ac6e9e2cf65f962e2e5089d0caff778908",
    "mode": 420
  },
  {
    "step": 19,
    "repo": "SDK",
    "path": "Sources/OsirisCamera/OsirisScanner/View/BarcodeBoundingBoxes.swift",
    "old": null,
    "sha256": "3a8d88e7c40ac751628cea1fc25772723e7c6f977905358431268b0c7c301a69",
    "mode": 420
  },
  {
    "step": 20,
    "repo": "SDK",
    "path": "Sources/OsirisCamera/OsirisScanner/View/CenterTextLayer.swift",
    "old": "Sources/OsirisBarcode/Util/CenterTextLayer.swift",
    "sha256": "d9053ff2bb0ca7d691c8da833687dc56b9052498f9158212fe3d796867c1db0a",
    "mode": 420
  },
  {
    "step": 21,
    "repo": "SDK",
    "path": "Sources/OsirisCamera/OsirisScanner/View/OsirisScannerView.swift",
    "old": null,
    "sha256": "2a115032e9cbfd36a9b8d16c9fded21e609a4b67b70713fa237db0099f65997a",
    "mode": 420
  },
  {
    "step": 22,
    "repo": "SDK",
    "path": "Sources/OsirisCamera/OsirisScanner/View/ScannerReticleView.swift",
    "old": null,
    "sha256": "9ed2fd77092a6fcb3b702cc404c279677694798a1a9f47acbd1c00c4d1935a91",
    "mode": 420
  },
  {
    "step": 23,
    "repo": "SDK",
    "path": "Sources/OsirisCamera/Util/Extensions/UserDefaults+ScanArea.swift",
    "old": null,
    "sha256": "2f2d49e28d003f0346daa4c5c755677958ae7382fbf9a32d206c90d4265799c4",
    "mode": 420
  },
  {
    "step": 24,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/OsirisDefaultResourceProvider.swift",
    "old": null,
    "sha256": "ca0922ab79b5130f098b13ba6e63e90302dc2b5ed9804562085fa907422776f3",
    "mode": 420
  },
  {
    "step": 25,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/Contents.json",
    "sha256": "0fd49ba3c3585c709678e0046a821c3c60685ec7063720d30d3a3448be3a208b",
    "mode": 420
  },
  {
    "step": 26,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/blue05.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/blue05.colorset/Contents.json",
    "sha256": "0ac044923ebe65e975f99214ed455ebc512b9da7be4c288e5a337e8fa3e118b2",
    "mode": 420
  },
  {
    "step": 27,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/blue10.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/blue10.colorset/Contents.json",
    "sha256": "b099213010e8fe617d6fe6786c9ac475e85f44ded1a10509a27b802c7355116f",
    "mode": 420
  },
  {
    "step": 28,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/blue100.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/blue100.colorset/Contents.json",
    "sha256": "f09d00d766a4dec530eb463da4aaae9df818fe05569e70ce7a0bc9c9416ca054",
    "mode": 420
  },
  {
    "step": 29,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/blue110.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/blue110.colorset/Contents.json",
    "sha256": "efaf6ac071aaee97f098f92bac7cf0238ad3499d23a5d05f275624e8a5930e96",
    "mode": 420
  },
  {
    "step": 30,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/blue120.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/blue120.colorset/Contents.json",
    "sha256": "182a7e1108805f013a19fbf6ce98fd4923f5c86a93c512d1c4ff8be916769e04",
    "mode": 420
  },
  {
    "step": 31,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/blue130.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/blue130.colorset/Contents.json",
    "sha256": "e8e169d9e31934e4071963b0023d48258ba67502f7ccf2f349a64722be4e4e18",
    "mode": 420
  },
  {
    "step": 32,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/blue140.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/blue140.colorset/Contents.json",
    "sha256": "781bc44f371d9dffbbde45df82aff6016b13b9ebba6d6f9d89fe7f241263c196",
    "mode": 420
  },
  {
    "step": 33,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/blue150.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/blue150.colorset/Contents.json",
    "sha256": "017e41253d377fdfd7cce82c6153b2c401a95c8996ea3fb6bc1e5f4472bac151",
    "mode": 420
  },
  {
    "step": 34,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/blue160.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/blue160.colorset/Contents.json",
    "sha256": "1089fd4001ee93e49e747a9a4f6b4ee4a45f843b26a0761b8f8015fc975129d5",
    "mode": 420
  },
  {
    "step": 35,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/blue170.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/blue170.colorset/Contents.json",
    "sha256": "af9cb43782292c5924c6e0c92fc66e724e761401bd05b483398666df878d43bb",
    "mode": 420
  },
  {
    "step": 36,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/blue180.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/blue180.colorset/Contents.json",
    "sha256": "56091e75cea1e79e04ed4cc6407f7c0cf156b9f902d2312155d6a7412d1a7c1f",
    "mode": 420
  },
  {
    "step": 37,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/blue20.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/blue20.colorset/Contents.json",
    "sha256": "40374876ba25dd31b34deb3653b878dfa12f5d375cb03e829e486c2bd9a1d32c",
    "mode": 420
  },
  {
    "step": 38,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/blue30.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/blue30.colorset/Contents.json",
    "sha256": "349a2ef674928f5988884abd574ffaf7b8d3fd341d4889c7bf84bc992e9e465d",
    "mode": 420
  },
  {
    "step": 39,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/blue40.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/blue40.colorset/Contents.json",
    "sha256": "c85fd3213ff4a64a880268220dfc91c8597198763516477ec0fe9da790c62313",
    "mode": 420
  },
  {
    "step": 40,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/blue50.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/blue50.colorset/Contents.json",
    "sha256": "617c18e5501b4294c4ffa70c36eac064c43d3fd64cea3a9a2d72eccf56067a94",
    "mode": 420
  },
  {
    "step": 41,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/blue60.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/blue60.colorset/Contents.json",
    "sha256": "9eb72237dc0891d4dac7dcb003111c1d858f1d3362d9b3999e33c2e025dea232",
    "mode": 420
  },
  {
    "step": 42,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/blue70.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/blue70.colorset/Contents.json",
    "sha256": "f6f7879a2a414d27cdd7331806a4fbdd526361f95e1d935f65699469ed9eadca",
    "mode": 420
  },
  {
    "step": 43,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/blue80.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/blue80.colorset/Contents.json",
    "sha256": "2204afde62c93c2381c22f16138f018a271c8d61a05b5a792cc796dded5de27b",
    "mode": 420
  },
  {
    "step": 44,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/blue90.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/blue90.colorset/Contents.json",
    "sha256": "1f061f08a197148a8d12685b54934d45c70e159e65c6f5a807cc7f581b059b83",
    "mode": 420
  },
  {
    "step": 45,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/clear.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/clear.colorset/Contents.json",
    "sha256": "e877705882c60f88eb37c175da1b420447a3940a29894bb1e9c20b5e5e2aad6e",
    "mode": 420
  },
  {
    "step": 46,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray00.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray00.colorset/Contents.json",
    "sha256": "990deafbfb947dc21d393d9914e622d4136337dfa6f3fb4bd370bfef9ad704c8",
    "mode": 420
  },
  {
    "step": 47,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray05.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray05.colorset/Contents.json",
    "sha256": "17da2897109101af5016abacb7264e69b3ea3697c60285298e632d05d1d2cf06",
    "mode": 420
  },
  {
    "step": 48,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray10.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray10.colorset/Contents.json",
    "sha256": "30e0d7f31f80ec759f42d12810616752c9affd9e4eb73c6b57718b9cb6b295d8",
    "mode": 420
  },
  {
    "step": 49,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray100.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray100.colorset/Contents.json",
    "sha256": "5d433a54c0f36ef166928c5c100efebdf49cb3e1ca5ff53b30c25138fcdde66c",
    "mode": 420
  },
  {
    "step": 50,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray110.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray110.colorset/Contents.json",
    "sha256": "47948703102444eedf416f3c9e2d68b451af39dd004bd26cdc4bcdff4d34a5b0",
    "mode": 420
  },
  {
    "step": 51,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray120.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray120.colorset/Contents.json",
    "sha256": "b4c79e476e67851375f2fd5d00f065ea3a3a0ca741daf6817b83fabbaca346cf",
    "mode": 420
  },
  {
    "step": 52,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray130.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray130.colorset/Contents.json",
    "sha256": "67ff418bd8dae0f636753922cef62443738a776ae2b1ab6bb0b07363fb9beb7d",
    "mode": 420
  },
  {
    "step": 53,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray140.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray140.colorset/Contents.json",
    "sha256": "07607e7988bc772b2371da64b4c766cb83616a5c07920d6d9e7e90933285e998",
    "mode": 420
  },
  {
    "step": 54,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray150.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray150.colorset/Contents.json",
    "sha256": "d7720d9e78cbef45a7646880ca46cee3b261acb1eb8519869e92709a9b28bfb1",
    "mode": 420
  },
  {
    "step": 55,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray160.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray160.colorset/Contents.json",
    "sha256": "84ccd198a65c0e06a817735586b06739b0981cc644a7795bf8d53a5cb4b7afb5",
    "mode": 420
  },
  {
    "step": 56,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray170.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray170.colorset/Contents.json",
    "sha256": "2eeb62a992d7434b599dbf3c91615322fd968e70c9ff2d920dc48c22a6fceb30",
    "mode": 420
  },
  {
    "step": 57,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray180.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray180.colorset/Contents.json",
    "sha256": "7dc7624685d8df8baff27b12313a6703a544a9f3943fd2a6b4a14cb10f9728bc",
    "mode": 420
  },
  {
    "step": 58,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray20.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray20.colorset/Contents.json",
    "sha256": "3608020d114354ff2d6b148b92b8a269e9acd7deda5f45176569ffcbcf914ddf",
    "mode": 420
  },
  {
    "step": 59,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray200.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray200.colorset/Contents.json",
    "sha256": "b3973d8e05ba3bacf901e1f77c0906b0e0b62592e0cfe172bddccb1d6ee099d7",
    "mode": 420
  },
  {
    "step": 60,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray30.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray30.colorset/Contents.json",
    "sha256": "a8d0745621ce32d7771faeaf5344c2b0a63209878c83eda822ad76de479a181c",
    "mode": 420
  },
  {
    "step": 61,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray40.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray40.colorset/Contents.json",
    "sha256": "bb024e55a71306eb4393b6b7c496233a15747d7dcacac1b749c7adc4b2567a65",
    "mode": 420
  },
  {
    "step": 62,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray50.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray50.colorset/Contents.json",
    "sha256": "75219b66e6ed3b55aff57c31adfc300f1447e6875c9971ce5d0a927c3f84c6d3",
    "mode": 420
  },
  {
    "step": 63,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray60.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray60.colorset/Contents.json",
    "sha256": "56d3ddb0a87466488e173f189795afc5b1533aeb4a7dc3bfaa56e3511c75bc3a",
    "mode": 420
  },
  {
    "step": 64,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray70.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray70.colorset/Contents.json",
    "sha256": "cf464b63356d60b04fc968e48036407dcc1dd2fa2e03851e9af1092d2768bf39",
    "mode": 420
  },
  {
    "step": 65,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray80.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray80.colorset/Contents.json",
    "sha256": "eb9f4bf8a08aa8b3efe5ef698075bdb23ed5152ed6b5de72e853e779fc7f7747",
    "mode": 420
  },
  {
    "step": 66,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/gray90.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/gray90.colorset/Contents.json",
    "sha256": "ef18d74353b11fb5a55fddac978ce85daf24b804a099d439f83245d9e5b0632f",
    "mode": 420
  },
  {
    "step": 67,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/green10.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/green10.colorset/Contents.json",
    "sha256": "04bd0324ce6f1eb26ca5fadab3faf09734ad59e9441992f19f5d8b61f74e2ce1",
    "mode": 420
  },
  {
    "step": 68,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/green100.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/green100.colorset/Contents.json",
    "sha256": "274c5a220a94833e8a1911626d72a6465e6b8c991159ba837f0d7d5f09b48146",
    "mode": 420
  },
  {
    "step": 69,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/green110.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/green110.colorset/Contents.json",
    "sha256": "90c36e60026b5bfa0e65c583aff0ffe2b4aac13aedc5475a40f7f835d95c82c3",
    "mode": 420
  },
  {
    "step": 70,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/green120.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/green120.colorset/Contents.json",
    "sha256": "4691f189c3cef831d11b80001f988380ceee8c75a889125742b37ab662161a16",
    "mode": 420
  },
  {
    "step": 71,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/green130.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/green130.colorset/Contents.json",
    "sha256": "634f822566d9e91141be0f3056a60ce0b05677b1634d9fdcd6f89221dc7e2fbf",
    "mode": 420
  },
  {
    "step": 72,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/green140.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/green140.colorset/Contents.json",
    "sha256": "6fe5b9ca86236433e0f5af920fbd0d5b628b89de6cbc450b59c17be0068e4f02",
    "mode": 420
  },
  {
    "step": 73,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/green150.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/green150.colorset/Contents.json",
    "sha256": "0951516800ce31f68c49dda2cb818d65827ac302f793e68edb5a59e0466ca25e",
    "mode": 420
  },
  {
    "step": 74,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/green160.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/green160.colorset/Contents.json",
    "sha256": "657760ba4607004f821d53716fc9283a2856edacdcf17afb2f927e70ee820b47",
    "mode": 420
  },
  {
    "step": 75,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/green170.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/green170.colorset/Contents.json",
    "sha256": "4a6c11c7ed387c8e43dedc4f66c320a308f0840483934d9db0fc575cd144d795",
    "mode": 420
  },
  {
    "step": 76,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/green180.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/green180.colorset/Contents.json",
    "sha256": "7d346d66e2ebfb673550a182ef0cbfdcdc410c7993e0640964d330c062bc457f",
    "mode": 420
  },
  {
    "step": 77,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/green20.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/green20.colorset/Contents.json",
    "sha256": "c09d6f08fd730307c162562f6d3eb02a36597ab99d360e66014afe130d29dd9e",
    "mode": 420
  },
  {
    "step": 78,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/green30.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/green30.colorset/Contents.json",
    "sha256": "088c6936d237fc3ce58d803c0d5035e3c441592122ed3cefaa018f61a5332611",
    "mode": 420
  },
  {
    "step": 79,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/green40.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/green40.colorset/Contents.json",
    "sha256": "8436591ac85c21b33cb2619d301e2b34f608ee75426b32216627c0e22bea9be1",
    "mode": 420
  },
  {
    "step": 80,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/green50.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/green50.colorset/Contents.json",
    "sha256": "311578299de45fc9c765f043d325c7c9be47f57e8976ee64f66d7d7088b1330d",
    "mode": 420
  },
  {
    "step": 81,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/green60.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/green60.colorset/Contents.json",
    "sha256": "0d61863b83ced29f637046f00314e0f7db5fd2dea2932cc23b8dac55d9aa5669",
    "mode": 420
  },
  {
    "step": 82,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/green70.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/green70.colorset/Contents.json",
    "sha256": "e8e7ef6b0f2b262486adb6e1ff579912ad452d0b9ec77d5476a5207389c0cc33",
    "mode": 420
  },
  {
    "step": 83,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/green80.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/green80.colorset/Contents.json",
    "sha256": "a68c1f9235c5526c16a5a78c7209986e88f789f4a45b1ff03f5eca350b3534ff",
    "mode": 420
  },
  {
    "step": 84,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/green90.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/green90.colorset/Contents.json",
    "sha256": "5c598161ccd6f7759dc663d1f6e595147fc2bcd099d3e8356de2a1d322569f7b",
    "mode": 420
  },
  {
    "step": 85,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/orange05.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/orange05.colorset/Contents.json",
    "sha256": "24fdae7273c1aa6d13ad5c4f871ceb7b2db6ec6b613ed5341e8f202ffffcdaed",
    "mode": 420
  },
  {
    "step": 86,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/orange10.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/orange10.colorset/Contents.json",
    "sha256": "0fe4aa5a2b71313ebc389d26398ebd9aef4785236b5b1feb52c52674ba8a6ab2",
    "mode": 420
  },
  {
    "step": 87,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/orange100.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/orange100.colorset/Contents.json",
    "sha256": "8317f5101a4e75bb0575386e921c95e91cc59628add18eb508bb03f166d484a4",
    "mode": 420
  },
  {
    "step": 88,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/orange110.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/orange110.colorset/Contents.json",
    "sha256": "a9d2554b6eaee627d34e6c1f3f182e1889fef913dbe7743dbf7047850e19940f",
    "mode": 420
  },
  {
    "step": 89,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/orange120.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/orange120.colorset/Contents.json",
    "sha256": "5ebc5bebc0f0859d176d97dee625a79b450a68d64f5ae91c87110c4a97b74ae1",
    "mode": 420
  },
  {
    "step": 90,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/orange130.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/orange130.colorset/Contents.json",
    "sha256": "4c7d0862fba2beae018e4fd629865b344cb7b0ea19b6ba820c0b306624b8aa8c",
    "mode": 420
  },
  {
    "step": 91,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/orange140.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/orange140.colorset/Contents.json",
    "sha256": "56baee0506b36237ee67ff50eb2f51dead2840d9354d0a3810fdcbcbc90b769f",
    "mode": 420
  },
  {
    "step": 92,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/orange150.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/orange150.colorset/Contents.json",
    "sha256": "3ab890178521f5b815045a2c24a2233369b7a91972e37e5bbf4fcd059763ab72",
    "mode": 420
  },
  {
    "step": 93,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/orange160.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/orange160.colorset/Contents.json",
    "sha256": "78aed8d3eacb2f1772a95d9e71b8d617b7c46a6f72d70e8de59e43c3b5056471",
    "mode": 420
  },
  {
    "step": 94,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/orange170.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/orange170.colorset/Contents.json",
    "sha256": "a61673a166f927e45bb94329b5fec8a2e1e35772377627b6e733cc34a43110ee",
    "mode": 420
  },
  {
    "step": 95,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/orange180.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/orange180.colorset/Contents.json",
    "sha256": "226282e01ecd11e039ea35319d00b8fd4e108808d43d9908ef20bb66c39a149a",
    "mode": 420
  },
  {
    "step": 96,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/orange20.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/orange20.colorset/Contents.json",
    "sha256": "aec0d58373c9e85b035043a84415a687f463c7c8bf5fd78822ddcc106fecac3f",
    "mode": 420
  },
  {
    "step": 97,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/orange30.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/orange30.colorset/Contents.json",
    "sha256": "2b56d63c880359c936cc603d4cf287d7741d1f5b59077ada05ad989662edd3c3",
    "mode": 420
  },
  {
    "step": 98,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/orange40.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/orange40.colorset/Contents.json",
    "sha256": "6cb76c08cf9735e82d5932818e7528eb86e34e676acfe5f6664e45ea112e0188",
    "mode": 420
  },
  {
    "step": 99,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/orange50.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/orange50.colorset/Contents.json",
    "sha256": "28d3abce8092c9d3d2505ac4ee9788c67aca19ae455108e66699be6926bba36d",
    "mode": 420
  },
  {
    "step": 100,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/orange60.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/orange60.colorset/Contents.json",
    "sha256": "931fd539b33871a77e8c45c9c5f0209df12f2faa6c5fb3c66ceb9cc68a99097a",
    "mode": 420
  },
  {
    "step": 101,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/orange70.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/orange70.colorset/Contents.json",
    "sha256": "66535c9b85666d6ed3119005d1f7ba148d82d707acefcbe9fe441cd2f457d93c",
    "mode": 420
  },
  {
    "step": 102,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/orange80.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/orange80.colorset/Contents.json",
    "sha256": "526290c891221ac1d782b5a76ab8c72c3bcf33c8d2db013244bd5da81a4f3ef8",
    "mode": 420
  },
  {
    "step": 103,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/orange90.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/orange90.colorset/Contents.json",
    "sha256": "bf70c3425274c3eee65ff59ee283cf95f2ebaecc500fbac8fd1d4f53c93b016b",
    "mode": 420
  },
  {
    "step": 104,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/pink05.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/pink05.colorset/Contents.json",
    "sha256": "2e50f852e8a99e06bfe0ce0f60d6cb52dba532f241c92da2a52d0d6c5c4cf174",
    "mode": 420
  },
  {
    "step": 105,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/pink10.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/pink10.colorset/Contents.json",
    "sha256": "7fb8f377193fab0a5c56a25401d60c3b5e573a32e2f95a60f856e2a484aeb1bc",
    "mode": 420
  },
  {
    "step": 106,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/pink100.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/pink100.colorset/Contents.json",
    "sha256": "13dd60a6a32b1ad9c56c43c375b272697d821a23e2d1e56bc35991be856cd16f",
    "mode": 420
  },
  {
    "step": 107,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/pink110.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/pink110.colorset/Contents.json",
    "sha256": "23da3465e81bb2b6f9edc3f9b3b94856532137581cdf012be2b10f43b9144001",
    "mode": 420
  },
  {
    "step": 108,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/pink120.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/pink120.colorset/Contents.json",
    "sha256": "17f587009f4a41013ecc7cd11547eb7adab154834e70ac86ec2a5906e5e57b46",
    "mode": 420
  },
  {
    "step": 109,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/pink130.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/pink130.colorset/Contents.json",
    "sha256": "0c63d2256339b60051d7b98da76c8386b650fef6ee89d631c2743e0085fdff60",
    "mode": 420
  },
  {
    "step": 110,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/pink140.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/pink140.colorset/Contents.json",
    "sha256": "081f9bb9411fba89bafa87f83324a462118a9fdd76e4bef597abf4a78c6bda4b",
    "mode": 420
  },
  {
    "step": 111,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/pink150.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/pink150.colorset/Contents.json",
    "sha256": "8f29bba38618f1f51f485f5fe48652a72000087a1df2d80babb7793290a94e3b",
    "mode": 420
  },
  {
    "step": 112,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/pink160.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/pink160.colorset/Contents.json",
    "sha256": "d36e4605b5b807d5025043d49da6f014460df8ed16d738b508e41091c3238cf6",
    "mode": 420
  },
  {
    "step": 113,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/pink170.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/pink170.colorset/Contents.json",
    "sha256": "79106451a79b1df8de6c857e82cd9828c9f2917ccce17cc5b6cc49e07843c126",
    "mode": 420
  },
  {
    "step": 114,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/pink180.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/pink180.colorset/Contents.json",
    "sha256": "dcc7917c47decb7006e115a8ce10b746dc3d0210f96636db2fe36e696230a3b3",
    "mode": 420
  },
  {
    "step": 115,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/pink20.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/pink20.colorset/Contents.json",
    "sha256": "16556d9ad613b124d1f7392395689fac721cc4de4b4b347f1bef016ea7f44f01",
    "mode": 420
  },
  {
    "step": 116,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/pink30.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/pink30.colorset/Contents.json",
    "sha256": "a6e57e2a0a0d47b5d56b56709a361a41b1dd335bbfd44fd017d487d75c301dff",
    "mode": 420
  },
  {
    "step": 117,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/pink40.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/pink40.colorset/Contents.json",
    "sha256": "b877d0d1a8baec8a83edef1778c2ed7906bc09784dfd63a9a018c34ad20c6129",
    "mode": 420
  },
  {
    "step": 118,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/pink50.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/pink50.colorset/Contents.json",
    "sha256": "e7aab7d4bc0e054a47383e19a536116aec8de7abfa0a4a0d40e5d0646ccd0584",
    "mode": 420
  },
  {
    "step": 119,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/pink60.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/pink60.colorset/Contents.json",
    "sha256": "7295d084f977cadd047c68cd00653b4a65e14cd790cb86648b8dd85ab3cc30e7",
    "mode": 420
  },
  {
    "step": 120,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/pink70.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/pink70.colorset/Contents.json",
    "sha256": "99b77517f31f2bbb65f0379cc9f4e0d75f979d4ff5ec99f93b9f2996fd6e9419",
    "mode": 420
  },
  {
    "step": 121,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/pink80.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/pink80.colorset/Contents.json",
    "sha256": "391a6741362acc9bd0eefb0a1b136da913575a10f5b29e38c00c5f051e073d00",
    "mode": 420
  },
  {
    "step": 122,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/pink90.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/pink90.colorset/Contents.json",
    "sha256": "6cc8f766d84f0c1757ca83298f02247fbf6493e393e66eb55efd03064bfe0b13",
    "mode": 420
  },
  {
    "step": 123,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/purple05.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/purple05.colorset/Contents.json",
    "sha256": "8ee7700901ab19b15d945c4012609d9ec226fb5d5f5979b5b3724b5605b8fbbe",
    "mode": 420
  },
  {
    "step": 124,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/purple10.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/purple10.colorset/Contents.json",
    "sha256": "fd8fe7d240a688ebbf60757d3a125ebab520039b99adbeecc3bea6dff3aea927",
    "mode": 420
  },
  {
    "step": 125,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/purple100.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/purple100.colorset/Contents.json",
    "sha256": "bd8f5ec84c91ddf54e1de57376fa659b1a5119876767346bf9e1e47db2fda583",
    "mode": 420
  },
  {
    "step": 126,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/purple110.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/purple110.colorset/Contents.json",
    "sha256": "50319369d668a6bf8899af859ac87d2d9de312b1a4ef41d2024d11e6af1036a6",
    "mode": 420
  },
  {
    "step": 127,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/purple120.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/purple120.colorset/Contents.json",
    "sha256": "ffba19b5e9b49cad8c3d8076c74a7fd755199149dcedbb14a287d9f8409ff1c4",
    "mode": 420
  },
  {
    "step": 128,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/purple130.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/purple130.colorset/Contents.json",
    "sha256": "14ad583e75d4c71ee04bd4506703154616767cb87ccbc02b77cb6bfa248fab67",
    "mode": 420
  },
  {
    "step": 129,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/purple140.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/purple140.colorset/Contents.json",
    "sha256": "2749b84a8527221fa3c82fe4b080772d3bf46217b2422336e92ff836904f6671",
    "mode": 420
  },
  {
    "step": 130,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/purple150.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/purple150.colorset/Contents.json",
    "sha256": "8e8b57895f1093a77bad22df3dce26d1e482182c66c181a78551891658d5b692",
    "mode": 420
  },
  {
    "step": 131,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/purple160.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/purple160.colorset/Contents.json",
    "sha256": "da267db7cdcc326e595e58ee03ade6ef4dd5b556bbde65c5ae4c76172c011617",
    "mode": 420
  },
  {
    "step": 132,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/purple170.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/purple170.colorset/Contents.json",
    "sha256": "a13d7add8bb7c7329f33086a09e11c8446c81454b3ba0179669efa3859afd216",
    "mode": 420
  },
  {
    "step": 133,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/purple180.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/purple180.colorset/Contents.json",
    "sha256": "424b4790b9633d39d500f7785117b4fdac5383d2176e759c2d0e6d1f7ac36eef",
    "mode": 420
  },
  {
    "step": 134,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/purple20.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/purple20.colorset/Contents.json",
    "sha256": "4df3c13d36111e99c756838b8987b464fc5b504b42086e5cfdec31b2c053d601",
    "mode": 420
  },
  {
    "step": 135,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/purple30.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/purple30.colorset/Contents.json",
    "sha256": "810da2fcb8f3c185dbe235250c881be5e41c6ade12fa1834d381cffcbca423bf",
    "mode": 420
  },
  {
    "step": 136,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/purple40.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/purple40.colorset/Contents.json",
    "sha256": "5f1c23d3d11a09804063f55da7558ca9fd7a79ee2404ee6525fc2242d6da8855",
    "mode": 420
  },
  {
    "step": 137,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/purple50.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/purple50.colorset/Contents.json",
    "sha256": "173f75ff5f2cfb0d903e48c8d0ef21ea741f4bc1e933cc83eb80e46c93826772",
    "mode": 420
  },
  {
    "step": 138,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/purple60.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/purple60.colorset/Contents.json",
    "sha256": "7c5e577e009a10e4f2ea3fc79f97ff1f2a940a67d6fa2b76e7e6f54d4dad0cb0",
    "mode": 420
  },
  {
    "step": 139,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/purple70.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/purple70.colorset/Contents.json",
    "sha256": "5f26edaa0fac9a8c7dc3da5484d2f652aa306229833726caecf432ac588d63ee",
    "mode": 420
  },
  {
    "step": 140,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/purple80.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/purple80.colorset/Contents.json",
    "sha256": "7e17c6dd85f42c55c3e1f6a1fe30915896f6098ffaa7e6847411460bb5083e37",
    "mode": 420
  },
  {
    "step": 141,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/purple90.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/purple90.colorset/Contents.json",
    "sha256": "f86eee408b0de2de988f2b157b079dbebd620640f8e821cf399a1df0ecbb8780",
    "mode": 420
  },
  {
    "step": 142,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/red05.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/red05.colorset/Contents.json",
    "sha256": "7bfc440e73c6fda32016698d31d28f7162719565979a3cfd43db6e58903a998b",
    "mode": 420
  },
  {
    "step": 143,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/red10.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/red10.colorset/Contents.json",
    "sha256": "5e1fd3ad58bed2feeae751b63be0d1964aa88b2adabf2e9e3a22b79502a58877",
    "mode": 420
  },
  {
    "step": 144,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/red100.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/red100.colorset/Contents.json",
    "sha256": "76b3b920e64b468c107c7342ea333d86fced0e0a0c6bd4bfa7750ac91fddc430",
    "mode": 420
  },
  {
    "step": 145,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/red110.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/red110.colorset/Contents.json",
    "sha256": "aea95820ce171630eb3db7fee138fb3064b21926d3f0ceb808f3ce4bafed3dfd",
    "mode": 420
  },
  {
    "step": 146,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/red120.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/red120.colorset/Contents.json",
    "sha256": "7ab3c9bf8f182d06a136a13a6357a358cab550d52f1db387457c14a5e280acf0",
    "mode": 420
  },
  {
    "step": 147,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/red130.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/red130.colorset/Contents.json",
    "sha256": "c572964861bab4cb6029776b2f97847dd63dd894d4c89766c532145917b8004c",
    "mode": 420
  },
  {
    "step": 148,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/red140.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/red140.colorset/Contents.json",
    "sha256": "6fd816b8f5512cace520adf880ab7fed45313a2795a0a65500be26e861da7738",
    "mode": 420
  },
  {
    "step": 149,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/red150.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/red150.colorset/Contents.json",
    "sha256": "2d47639fef109ecefae858ec94704550a9225029c78461b1d13e87945dc15ef5",
    "mode": 420
  },
  {
    "step": 150,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/red160.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/red160.colorset/Contents.json",
    "sha256": "1c6aa36b450a628990d98e45ffff808a317318ea70a6724f02f0cc8e02a76800",
    "mode": 420
  },
  {
    "step": 151,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/red170.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/red170.colorset/Contents.json",
    "sha256": "e49a8b339148dd91f0c9947e8369de2d4a024b7d716ce09496571ca7cc1a0214",
    "mode": 420
  },
  {
    "step": 152,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/red180.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/red180.colorset/Contents.json",
    "sha256": "9ccf6fe2298d2359ea372f81d9791070596cfc8318d09b4a79c41273f2e421d6",
    "mode": 420
  },
  {
    "step": 153,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/red20.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/red20.colorset/Contents.json",
    "sha256": "48082eac659c17882f5f0642c78c4a68780b6a28e6dac07ce25954e83a6f54b4",
    "mode": 420
  },
  {
    "step": 154,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/red30.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/red30.colorset/Contents.json",
    "sha256": "5dd7a19d968a37f4b9ed86789daafdf03b293f4b99f3fb0e8a4482dbc3a30858",
    "mode": 420
  },
  {
    "step": 155,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/red40.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/red40.colorset/Contents.json",
    "sha256": "fde4dfb78067a006d573e23d20d0cabcc67e3bc6d47fbb6fc3b73234812b0e88",
    "mode": 420
  },
  {
    "step": 156,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/red50.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/red50.colorset/Contents.json",
    "sha256": "d725144e745d03ba51531d61dca7e96b42b3c8a634ee3791e16df7280b366985",
    "mode": 420
  },
  {
    "step": 157,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/red60.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/red60.colorset/Contents.json",
    "sha256": "48e83d7b8ceda0ca1b4a7317c62840f178568f445f6753450ed95e8576f0a4cd",
    "mode": 420
  },
  {
    "step": 158,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/red70.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/red70.colorset/Contents.json",
    "sha256": "fc8581ad598f5ef7a0d16aa82f92b38d19d048719c65cf9b8c16125aca10daff",
    "mode": 420
  },
  {
    "step": 159,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/red80.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/red80.colorset/Contents.json",
    "sha256": "38dd1dd26a1546a537413a1d44401f0c8c9fca6bd95881482b49335e7a1c0115",
    "mode": 420
  },
  {
    "step": 160,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/red90.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/red90.colorset/Contents.json",
    "sha256": "8b8e12e0a0e4245bd8ac98e46a53cb5b137b7a238261b26bf099a3982005e4dd",
    "mode": 420
  },
  {
    "step": 161,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/spark05.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/spark05.colorset/Contents.json",
    "sha256": "18bda87b07221e7fa3f3417e83c88a11cb31268b789d42aa0db75bf9fbf01f0b",
    "mode": 420
  },
  {
    "step": 162,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/spark10.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/spark10.colorset/Contents.json",
    "sha256": "b129e2dd28d20bb98fd47941206f0a249bdb355d06b2ffc5aa919e9741c68eb9",
    "mode": 420
  },
  {
    "step": 163,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/spark100.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/spark100.colorset/Contents.json",
    "sha256": "f5949baed232b097536cac60345db454f338130f79e91425c56636a25dcc03e7",
    "mode": 420
  },
  {
    "step": 164,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/spark110.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/spark110.colorset/Contents.json",
    "sha256": "1aa1af53d23ed92808746175e1cd81c106a99964123b207758498b1aea935ce3",
    "mode": 420
  },
  {
    "step": 165,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/spark120.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/spark120.colorset/Contents.json",
    "sha256": "9cf0ab6d9c6c6af4fb8b7853253a6ba06a762d9dd3fe99881288eb12434fcdd1",
    "mode": 420
  },
  {
    "step": 166,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/spark130.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/spark130.colorset/Contents.json",
    "sha256": "40a4a1cbc6fcb1c80837817479487113eaf0a3bd8feeb43658b3e862847e2496",
    "mode": 420
  },
  {
    "step": 167,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/spark140.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/spark140.colorset/Contents.json",
    "sha256": "689c3df9e32c0268879696f53bec5058f483c60e3e2c64fea163dae73821a5ee",
    "mode": 420
  },
  {
    "step": 168,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/spark150.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/spark150.colorset/Contents.json",
    "sha256": "e150bb2932d4e46d3abc1ddf00c9560eea25997b39631d0c1da4b2027bedb545",
    "mode": 420
  },
  {
    "step": 169,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/spark160.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/spark160.colorset/Contents.json",
    "sha256": "4ed2ed9cd0f52cb1c523f7a78aa7e3444e6de1d02086c0acace72c6dc8dc34f3",
    "mode": 420
  },
  {
    "step": 170,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/spark170.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/spark170.colorset/Contents.json",
    "sha256": "ad0ee80fa97df83f5f3386ea28b2ad714840dc6c69125aacb8ac126081fa556f",
    "mode": 420
  },
  {
    "step": 171,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/spark180.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/spark180.colorset/Contents.json",
    "sha256": "ab270721f6ed8996f2f8d1fd40af80762cf06ef8650afb469f31d0bba75b6b49",
    "mode": 420
  },
  {
    "step": 172,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/spark20.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/spark20.colorset/Contents.json",
    "sha256": "e294f1b6d627512953ca0a373ee43f8e96fdb4a5b6cf74c03532c130fc11c4f2",
    "mode": 420
  },
  {
    "step": 173,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/spark30.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/spark30.colorset/Contents.json",
    "sha256": "4e90da3225de1877a877510c886532ad37dc9d6f31b3c17c9f5c89d57486d25a",
    "mode": 420
  },
  {
    "step": 174,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/spark40.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/spark40.colorset/Contents.json",
    "sha256": "64cdcd36f7ca41ae4b59bf91f93f28e339496b5a22b98a68a6a567d3b591b1e6",
    "mode": 420
  },
  {
    "step": 175,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/spark50.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/spark50.colorset/Contents.json",
    "sha256": "e064ce324540b8bf949baa05a0d48185e875a8484876295263b2688afc367b08",
    "mode": 420
  },
  {
    "step": 176,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/spark60.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/spark60.colorset/Contents.json",
    "sha256": "33b2c5c5d26a29813391ac27dfc023c4eba98693ff92b1185ea8919eb2f7c0ad",
    "mode": 420
  },
  {
    "step": 177,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/spark70.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/spark70.colorset/Contents.json",
    "sha256": "6ab4012bf3aea8a8efba54640db0a20d46c68002ddd1d828ef450025241cbd7c",
    "mode": 420
  },
  {
    "step": 178,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/spark80.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/spark80.colorset/Contents.json",
    "sha256": "377d8c95b906670ad4957d2cbe3e99ecb058cb2fff407d66a666c5d34ca41322",
    "mode": 420
  },
  {
    "step": 179,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/spark90.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/spark90.colorset/Contents.json",
    "sha256": "adf24ebe5e20fff78f0a12c214bc745769db95ffd329379101be465257a98ad2",
    "mode": 420
  },
  {
    "step": 180,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/yellow05.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/yellow05.colorset/Contents.json",
    "sha256": "6867edae8708da4ea060afef515ff2558940f3094bb0e7b7f2bb6410c2e5266e",
    "mode": 420
  },
  {
    "step": 181,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/yellow10.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/yellow10.colorset/Contents.json",
    "sha256": "98f2e5958fd601ed4777fa27d85e512f8835e6b4ef717beb93608519a23e563e",
    "mode": 420
  },
  {
    "step": 182,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/yellow100.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/yellow100.colorset/Contents.json",
    "sha256": "ae39342fbc4183102ca3fa8be9c65b47ef7d604b481f205c257b1067e5ba1614",
    "mode": 420
  },
  {
    "step": 183,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/yellow110.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/yellow110.colorset/Contents.json",
    "sha256": "4f5320ac2be3a52e15e3b15ea180b0fd56183a9210abcd1918f9f2fe1e8e8881",
    "mode": 420
  },
  {
    "step": 184,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/yellow120.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/yellow120.colorset/Contents.json",
    "sha256": "d2ff79efb293a72403e4c64c5c5b6ac90deaef45083c882f9b119714aa63cdc1",
    "mode": 420
  },
  {
    "step": 185,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/yellow130.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/yellow130.colorset/Contents.json",
    "sha256": "692aebe07041cd8ae4e8aaf81794bd26c4827ef7e0766a9d5f644199dcda12d5",
    "mode": 420
  },
  {
    "step": 186,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/yellow140.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/yellow140.colorset/Contents.json",
    "sha256": "8a30a34d201b3428902a5478918f2dbd342f8fc3196e640232cbc622569b02fe",
    "mode": 420
  },
  {
    "step": 187,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/yellow150.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/yellow150.colorset/Contents.json",
    "sha256": "b83fc05824e9a67d3bb6fafa065a3aa33cab39d8917c0105979ac3eaaf9f327a",
    "mode": 420
  },
  {
    "step": 188,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/yellow160.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/yellow160.colorset/Contents.json",
    "sha256": "b38dc8b377b3301451511e64a546da12e6ff0499543bcdbac28b5bbd9489b6ab",
    "mode": 420
  },
  {
    "step": 189,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/yellow170.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/yellow170.colorset/Contents.json",
    "sha256": "22ccf7dba645df53408b324f2f5aa2668b1f887cf629f16cd16258b1f200fe36",
    "mode": 420
  },
  {
    "step": 190,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/yellow180.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/yellow180.colorset/Contents.json",
    "sha256": "8969a70b9770e88ccd808248a0b97a542b7b76e801bccd9bb61b25c1dfabf635",
    "mode": 420
  },
  {
    "step": 191,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/yellow20.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/yellow20.colorset/Contents.json",
    "sha256": "2c3c850b8c27e4bb29a13e7545f61a63bc8a4497397c956324fccd406e2c3aa1",
    "mode": 420
  },
  {
    "step": 192,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/yellow30.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/yellow30.colorset/Contents.json",
    "sha256": "ec705462abe8c75a1dba4764bd827cb5fd0d34b950d2b480d27a3327f34a3457",
    "mode": 420
  },
  {
    "step": 193,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/yellow40.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/yellow40.colorset/Contents.json",
    "sha256": "971e21e703c0154232598c26a7e09a2c6ca4b1b00b6cabe92d24cf19d9c71046",
    "mode": 420
  },
  {
    "step": 194,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/yellow50.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/yellow50.colorset/Contents.json",
    "sha256": "85870f7919029e22473035ea699b2ffbbb9808983941ee37b01d29e0c0f54189",
    "mode": 420
  },
  {
    "step": 195,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/yellow60.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/yellow60.colorset/Contents.json",
    "sha256": "8c19a0775fa342aa69bacae5730f30b38cc16e529d7e0b492a8fc38460665f4e",
    "mode": 420
  },
  {
    "step": 196,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/yellow70.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/yellow70.colorset/Contents.json",
    "sha256": "bbac8709fe34c5c036b082cc9087365e6091b13828c0dd63f8de052a98e0198d",
    "mode": 420
  },
  {
    "step": 197,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/yellow80.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/yellow80.colorset/Contents.json",
    "sha256": "11f9f609dcbea1c4cce9d6f521b14baeb1e227e3aaf4a6dc3ac5673134214ab3",
    "mode": 420
  },
  {
    "step": 198,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Colors.xcassets/yellow90.colorset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Colors.xcassets/yellow90.colorset/Contents.json",
    "sha256": "9fcca51294a0d604947d464b76fde770f6777a15f6b5c0e5cc50a63adea27b3b",
    "mode": 420
  },
  {
    "step": 199,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/Contents.json",
    "sha256": "0fd49ba3c3585c709678e0046a821c3c60685ec7063720d30d3a3448be3a208b",
    "mode": 420
  },
  {
    "step": 200,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/ic_barcode.imageset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/ic_barcode.imageset/Contents.json",
    "sha256": "b42f646a341b3ed6bc8b7e6f314209c1d294ef4eaa944736c7207099e9890759",
    "mode": 420
  },
  {
    "step": 201,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/ic_barcode.imageset/ic_barcode.svg",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/ic_barcode.imageset/ic_barcode.svg",
    "sha256": "4dc59dbb2b774a46ae66bc4010f9fb1412c55ed5197036b43e11b451eeca20ee",
    "mode": 420
  },
  {
    "step": 202,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/ic_caret_down.imageset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/ic_caret_down.imageset/Contents.json",
    "sha256": "c1e0fd572b656e1a5793a489aa48e7ab12cad73dfc8770dac3b936beb18a6230",
    "mode": 420
  },
  {
    "step": 203,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/ic_caret_down.imageset/ic_caret_down.svg",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/ic_caret_down.imageset/ic_caret_down.svg",
    "sha256": "73b3b4304c16b521835800df09e7f39c71a86b31968299865041d00e505972b2",
    "mode": 420
  },
  {
    "step": 204,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/ic_chevron_left.imageset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/ic_chevron_left.imageset/Contents.json",
    "sha256": "64f3fcbcbb4ee6bc74c70b0e1e2ab2d70a41a1846d4d91122e219be9d2243c71",
    "mode": 420
  },
  {
    "step": 205,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/ic_chevron_left.imageset/ic_chevron_left_l.svg",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/ic_chevron_left.imageset/ic_chevron_left_l.svg",
    "sha256": "40d67f722165af440c319c98850bbe2dae6fb1755fd23565eca09a9d8edaf013",
    "mode": 420
  },
  {
    "step": 206,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/ic_chevron_left.imageset/ic_chevron_left_m.svg",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/ic_chevron_left.imageset/ic_chevron_left_m.svg",
    "sha256": "8535b70c5a88ebef2b1dc707c2283d677c86af9e6a983971343527ec2ee45d75",
    "mode": 420
  },
  {
    "step": 207,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/ic_chevron_left.imageset/ic_chevron_left_s.svg",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/ic_chevron_left.imageset/ic_chevron_left_s.svg",
    "sha256": "1ee2ae671023ca6a332423c5035af08553bdf4bec54fd395267bcca70329f350",
    "mode": 420
  },
  {
    "step": 208,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/ic_close.imageset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/ic_close.imageset/Contents.json",
    "sha256": "4279db6ccc5d887cee31c5fc51783c7cb78e4421db59af7968629e648eb0ef1a",
    "mode": 420
  },
  {
    "step": 209,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/ic_close.imageset/ic_close_l.svg",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/ic_close.imageset/ic_close_l.svg",
    "sha256": "6213b28c849bee3dc030a8a21efd1b07155b8ad0a6852275cca4e62b0f8000ba",
    "mode": 420
  },
  {
    "step": 210,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/ic_close.imageset/ic_close_m.svg",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/ic_close.imageset/ic_close_m.svg",
    "sha256": "8148a7c8dae288f0e94ebd961d493caa0d313818a97b9d9dff3b1635d37d484f",
    "mode": 420
  },
  {
    "step": 211,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/ic_close.imageset/ic_close_s.svg",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/ic_close.imageset/ic_close_s.svg",
    "sha256": "1310b21ea622bfaf9edd5d49cacc0e2dcdb2b4da85d7ea549b03d55cd074f86a",
    "mode": 420
  },
  {
    "step": 212,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/icons/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/icons/Contents.json",
    "sha256": "0fd49ba3c3585c709678e0046a821c3c60685ec7063720d30d3a3448be3a208b",
    "mode": 420
  },
  {
    "step": 213,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/icons/ic_flash.imageset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/icons/ic_flash.imageset/Contents.json",
    "sha256": "02db0bc9f207b33a656d53dd32694b7941922d7540d5c1b9cd23779723feb238",
    "mode": 420
  },
  {
    "step": 214,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/icons/ic_flash.imageset/ic_flash.svg",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/icons/ic_flash.imageset/ic_flash.svg",
    "sha256": "6a74585822e5c3ba489233a6aa42528612f5e1f82e2938628bf2f8b128cd4d51",
    "mode": 420
  },
  {
    "step": 215,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/icons/ic_flash_slash.imageset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/icons/ic_flash_slash.imageset/Contents.json",
    "sha256": "038c1a5076d976260abad33fe948f1536edf0f668dc97caff367b33763a38065",
    "mode": 420
  },
  {
    "step": 216,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/icons/ic_flash_slash.imageset/ic_flash_slash.svg",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/icons/ic_flash_slash.imageset/ic_flash_slash.svg",
    "sha256": "1f071ccbb02ef508c6162bb9ba2690628b0d88ac58da21621b4828ef1ae8da55",
    "mode": 420
  },
  {
    "step": 217,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/icons/ic_frame_bottom_left.imageset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/icons/ic_frame_bottom_left.imageset/Contents.json",
    "sha256": "eb07ca1f423cd7fb2b43d7a8d02004881cdbbe25ce30520edd7e9c3577f12cbe",
    "mode": 420
  },
  {
    "step": 218,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/icons/ic_frame_bottom_left.imageset/ic_frame_bottom_left.svg",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/icons/ic_frame_bottom_left.imageset/ic_frame_bottom_left.svg",
    "sha256": "db5955db052a51fb0e10899a791318bc8865fa7d1ccfad1d58dc36a634d7984e",
    "mode": 420
  },
  {
    "step": 219,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/icons/ic_frame_bottom_right.imageset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/icons/ic_frame_bottom_right.imageset/Contents.json",
    "sha256": "c854b2097e9de7b00eed0ba85e6dc89fb5dcb2dc21e7d495a8e2947f47eb6143",
    "mode": 420
  },
  {
    "step": 220,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/icons/ic_frame_bottom_right.imageset/ic_frame_bottom_right.svg",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/icons/ic_frame_bottom_right.imageset/ic_frame_bottom_right.svg",
    "sha256": "3075b22ab0f3b45fb4220aa10c95c5dc5946a0205a4d459eef9213a748035478",
    "mode": 420
  },
  {
    "step": 221,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/icons/ic_frame_top_left.imageset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/icons/ic_frame_top_left.imageset/Contents.json",
    "sha256": "83f55452210aae74056c39706b6fa730c0887f93c55f1e27ae3180aa4abf60e0",
    "mode": 420
  },
  {
    "step": 222,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/icons/ic_frame_top_left.imageset/ic_frame_top_left.svg",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/icons/ic_frame_top_left.imageset/ic_frame_top_left.svg",
    "sha256": "a89ba535f83007a44a5073e78cba8149b091dfeb60f16480b7a34475fb2de557",
    "mode": 420
  },
  {
    "step": 223,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/icons/ic_frame_top_right.imageset/Contents.json",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/icons/ic_frame_top_right.imageset/Contents.json",
    "sha256": "57f259ce37c03cac194966558315357fc2eef48892946d72de53af2d298ff38c",
    "mode": 420
  },
  {
    "step": 224,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Assets/Images.xcassets/icons/ic_frame_top_right.imageset/ic_frame_top_right.svg",
    "old": "Sources/Osiris/OsirisCore/UI/Assets/Images.xcassets/icons/ic_frame_top_right.imageset/ic_frame_top_right.svg",
    "sha256": "5d382529c13af4c6664167901c1e2768cb20b949f7c6fae3aa40ec4a1ba5429c",
    "mode": 420
  },
  {
    "step": 225,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Fonts/Bogle-Bold.otf",
    "old": "Sources/Osiris/OsirisCore/UI/Fonts/Bogle-Bold.otf",
    "sha256": "91c8e5943f290b41ddf138ac61f95529b02601da7a2ceb95cbdb9ac5ea764a9a",
    "mode": 420
  },
  {
    "step": 226,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Fonts/Bogle-Regular.otf",
    "old": "Sources/Osiris/OsirisCore/UI/Fonts/Bogle-Regular.otf",
    "sha256": "3493583fcc73787007bac877626159a438ac05ac7be3c4e612ff7326b38f3899",
    "mode": 420
  },
  {
    "step": 227,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Fonts/BogleMono-Bold.otf",
    "old": "Sources/Osiris/OsirisCore/UI/Fonts/BogleMono-Bold.otf",
    "sha256": "c96f2b58ffdccfc5ee811ccad7177ff45556635289317c265555cd8d7a5557fc",
    "mode": 420
  },
  {
    "step": 228,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/Fonts/BogleMono-Regular.otf",
    "old": "Sources/Osiris/OsirisCore/UI/Fonts/BogleMono-Regular.otf",
    "sha256": "587cf263824bb8ac54f2c327b1e0c21c2da5e4854b36d8cca9f6fc7f74cb4674",
    "mode": 420
  },
  {
    "step": 229,
    "repo": "SDK",
    "path": "Sources/OsirisDefaultResources/Resources/scanbeep.wav",
    "old": "Sources/Osiris/Integration/Resources/scanbeep.wav",
    "sha256": "1c20e667c004a24a21d07cf7624b9bcfb5e743f0c0b116bcc1ba800c8b9f2ea4",
    "mode": 420
  },
  {
    "step": 230,
    "repo": "SDK",
    "path": "Tests/Osiris-Pacakage.xctestplan",
    "old": null,
    "sha256": "32e4223ed97b57493065ebf73f5cc3fa2d81b335dc6e57ebc3d12b51e5c3f68c",
    "mode": 420
  },
  {
    "step": 231,
    "repo": "SDK",
    "path": "Tests/OsirisDefaultResourcesTests/DefaultResourcesTests.swift",
    "old": null,
    "sha256": "e997277f97d5b19a15fe5753963aa67181ee032d09315e50c3d20d6627cf42b8",
    "mode": 420
  },
  {
    "step": 232,
    "repo": "SDK",
    "path": "Tests/OsirisHeadlessTests/Fixtures/gs1-datamatrix.png",
    "old": null,
    "sha256": "cc2cf50d0dda603cd55a17e66b96dc0cf0a33f290547b5af85ecc421490971d6",
    "mode": 420
  },
  {
    "step": 233,
    "repo": "SDK",
    "path": "Tests/OsirisHeadlessTests/HeadlessBarcodeDecoderTests.swift",
    "old": null,
    "sha256": "7c3028f637348169fa5b41184ee4c17fc12a536f9160d1aa5d244940bfc7ebc8",
    "mode": 420
  },
  {
    "step": 234,
    "repo": "SDK",
    "path": "Tests/OsirisTests/ScannerResourceTests.swift",
    "old": null,
    "sha256": "95327af9aaa57f4040d537e3e8b33e4e2eaf33ce45a3c4038b0ea7963c1c5ad4",
    "mode": 420
  },
  {
    "step": 235,
    "repo": "SDK",
    "path": "README.md",
    "old": null,
    "sha256": "a1cf921ce968236268810c8e3a514d06b8d985034273fafb14295e4c803786fc",
    "mode": 420
  },
  {
    "step": 236,
    "repo": "SDK",
    "path": "ci_scripts/xcframework-build.sh",
    "old": null,
    "sha256": "4860a83b3a0dd90b77d359506cbd244af9957e58e222e603f08624ae2c15d910",
    "mode": 493
  },
  {
    "step": 237,
    "repo": "SDK",
    "path": "fastlane/Fastfile",
    "old": null,
    "sha256": "bb7d1d64734e9eac0e093337f207f999b416ff2c294ee0c0000a6c7b932a644e",
    "mode": 420
  },
  {
    "step": 238,
    "repo": "SDK",
    "path": "podspec-util.sh",
    "old": null,
    "sha256": "137d02979c45da2153bd01a462664980d2994842fbd1397e2e8a66aec2e0a90f",
    "mode": 493
  },
  {
    "step": 239,
    "repo": "Diamond",
    "path": "Podfile",
    "old": null,
    "sha256": "6d4ea6a11093717157c1208a1e3d2dc9928ae31b81aae583050617a4406ab4c0",
    "mode": 420
  },
  {
    "step": 240,
    "repo": "Diamond",
    "path": "README.md",
    "old": null,
    "sha256": "6780e8b764a13e1849de0841ca81032799fa7535e4dcef1971a460ba2fd991e7",
    "mode": 420
  },
  {
    "step": 241,
    "repo": "Diamond",
    "path": "Source/System/AppDelegate.swift",
    "old": null,
    "sha256": "d94cee8a218d56ad3cae526db80ee88b33d1ae8484c93620894a23144f382bf0",
    "mode": 420
  },
  {
    "step": 242,
    "repo": "Diamond",
    "path": "Source/UI/BarcodeSingleScan/ViewModel/BarcodeSingleScanViewModel.swift",
    "old": null,
    "sha256": "ba6ed62b6604aa4597d72be510b08726c2e2a74285ebe314abf8a122fe0fd923",
    "mode": 420
  }
]
''')
LABELS = {"SDK": "OsirisSDK", "Diamond": "Diamond"}


class TransferError(Exception):
    pass


def checksum(data):
    return hashlib.sha256(data).hexdigest()


def inside(path, parent):
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def safe_path(root, relative):
    parts = PurePosixPath(relative).parts
    if not parts or relative != "/".join(parts) or PurePosixPath(relative).is_absolute():
        raise TransferError("Invalid path: " + relative)
    if any(p in (".", "..", ".git") for p in parts) or "\\" in relative:
        raise TransferError("Invalid or protected path: " + relative)
    path = root
    for index, part in enumerate(parts):
        path = path / part
        if path.is_symlink():
            raise TransferError("Refusing a symbolic link: " + str(path))
        if index < len(parts) - 1 and path.exists() and not path.is_dir():
            raise TransferError("Expected a directory: " + str(path))
    return path


def fingerprint(path):
    if path.is_symlink():
        raise TransferError("Refusing a symbolic link: " + str(path))
    if not path.exists():
        return None
    info = path.stat()
    if not stat.S_ISREG(info.st_mode):
        raise TransferError("Expected a regular file: " + str(path))
    return {"sha256": checksum(path.read_bytes()), "mode": stat.S_IMODE(info.st_mode) & 0o777}


def replace_bytes(path, data, mode):
    path.parent.mkdir(parents=True, exist_ok=True)
    handle, name = tempfile.mkstemp(prefix=".osiris-transfer-", dir=str(path.parent))
    temporary = Path(name)
    try:
        with os.fdopen(handle, "wb") as output:
            output.write(data)
            output.flush()
            os.fsync(output.fileno())
        temporary.chmod(mode)
        os.replace(str(temporary), str(path))
    finally:
        if temporary.exists():
            temporary.unlink()


def target_roots(arguments, package):
    roots = {}
    markers = {"SDK": ("Package.swift", "Osiris.podspec", "Sources"), "Diamond": ("Podfile", "Diamond.xcodeproj", "Source")}
    for repo, argument in (("SDK", arguments.sdk), ("Diamond", arguments.diamond)):
        if argument:
            root = Path(argument).expanduser().resolve(strict=True)
            if any(inside(root, package / label) for label in LABELS.values()):
                raise TransferError("Choose your real checkout, not the prepared source folder.")
            if not root.is_dir() or not all(safe_path(root, p).exists() for p in markers[repo]):
                raise TransferError("This does not look like the " + repo + " checkout: " + str(root))
            roots[repo] = root
    if len(roots) == 2 and (inside(roots["SDK"], roots["Diamond"]) or inside(roots["Diamond"], roots["SDK"])):
        raise TransferError("SDK and Diamond must be separate checkout folders.")
    return roots


def prepare(package, roots):
    changes = []
    selected = 0
    for operation in OPERATIONS:
        repo, relative = operation["repo"], operation["path"]
        if repo not in roots:
            continue
        selected += 1
        source = safe_path(package, LABELS[repo] + "/" + relative)
        data = source.read_bytes()
        if checksum(data) != operation["sha256"]:
            raise TransferError("Prepared file differs from this revised package: " + str(source))
        target = safe_path(roots[repo], relative)
        before = fingerprint(target)
        after = {"sha256": operation["sha256"], "mode": operation["mode"]}
        if before != after:
            changes.append({"repo": repo, "path": relative, "before": before, "after": after, "data": data})
        if operation["old"]:
            old = safe_path(roots[repo], operation["old"])
            before = fingerprint(old)
            if before:
                changes.append({"repo": repo, "path": operation["old"], "before": before, "after": None, "data": None})
    changes.sort(key=lambda item: item["after"] is None)
    return changes, selected


def verify_before(change, roots):
    path = safe_path(roots[change["repo"]], change["path"])
    if fingerprint(path) != change["before"]:
        raise TransferError("File changed while the script was running: " + str(path))
    return path


def save_journal(backup, journal):
    replace_bytes(backup / "backup.json", (json.dumps(journal, indent=2) + "\n").encode(), 0o600)


def apply_changes(changes, roots):
    backup_parent = roots["SDK"].parent / "osiris-transfer-backups"
    if backup_parent.is_symlink():
        raise TransferError("Refusing a symbolic-link backup folder.")
    backup_parent.mkdir(parents=True, exist_ok=True)
    backup = Path(tempfile.mkdtemp(prefix=datetime.now().strftime("%Y%m%d-%H%M%S-"), dir=str(backup_parent)))
    backup.chmod(0o700)
    journal = {"status": "preparing", "roots": {repo: str(root) for repo, root in roots.items()}, "files": []}
    for change in changes:
        target = verify_before(change, roots)
        if change["before"]:
            data = target.read_bytes()
            if checksum(data) != change["before"]["sha256"]:
                raise TransferError("File changed during backup: " + str(target))
            saved = safe_path(backup, "before/" + LABELS[change["repo"]] + "/" + change["path"])
            replace_bytes(saved, data, change["before"]["mode"])
        journal["files"].append({key: change[key] for key in ("repo", "path", "before", "after")})
    journal["status"] = "ready"
    save_journal(backup, journal)
    print("Backup: " + str(backup), flush=True)
    try:
        for change in changes:
            target = verify_before(change, roots)
            if change["after"]:
                replace_bytes(target, change["data"], change["after"]["mode"])
            else:
                target.unlink()
            if fingerprint(target) != change["after"]:
                raise TransferError("Verification failed: " + str(target))
        journal["status"] = "complete"
        save_journal(backup, journal)
    except BaseException as error:
        failures = []
        for change in reversed(changes):
            try:
                target = safe_path(roots[change["repo"]], change["path"])
                current = fingerprint(target)
                if current == change["before"]:
                    continue
                if current != change["after"]:
                    raise TransferError("Changed independently; left untouched: " + str(target))
                if change["before"]:
                    saved = safe_path(backup, "before/" + LABELS[change["repo"]] + "/" + change["path"])
                    data = saved.read_bytes()
                    if checksum(data) != change["before"]["sha256"]:
                        raise TransferError("Backup checksum mismatch: " + str(saved))
                    replace_bytes(target, data, change["before"]["mode"])
                else:
                    target.unlink()
            except (OSError, TransferError) as rollback_error:
                failures.append(str(rollback_error))
        journal["status"] = "rollback-needs-attention" if failures else "rolled-back"
        try:
            save_journal(backup, journal)
        except OSError as journal_error:
            failures.append(str(journal_error))
        detail = "\n".join(failures) if failures else "Completed changes were rolled back."
        raise TransferError(str(error) + "\n" + detail + "\nBackup: " + str(backup)) from error
    for change in changes:
        if change["after"] is None:
            root = roots[change["repo"]]
            parent = safe_path(root, change["path"]).parent
            while parent != root:
                try:
                    parent.rmdir()
                except OSError:
                    break
                parent = parent.parent
    print("Transfer complete. Listed files were copied and old move locations removed.")


def main(argv=None):
    parser = argparse.ArgumentParser(description="Apply the 242 revised checklist actions to an untouched checkout. Preview by default; no earlier-package cleanup or merge logic.")
    parser.add_argument("--sdk", required=True, help="Path to your real newest osiris-ios checkout")
    parser.add_argument("--diamond", help="Path to your real diamond-ios-sdk checkout; omit for SDK only")
    parser.add_argument("--apply", action="store_true", help="Back up and transfer files; otherwise only preview")
    arguments = parser.parse_args(argv)
    try:
        package = Path(__file__).resolve().parent
        roots = target_roots(arguments, package)
        changes, selected = prepare(package, roots)
        print("Fresh-checkout transfer: " + str(selected) + " checklist steps selected.")
        print("Listed destination files will be replaced with the prepared versions. No merge or earlier-package cleanup is performed.")
        for repo, root in roots.items():
            print(repo + ": " + str(root))
        for change in changes:
            print(("COPY " if change["after"] else "REMOVE ") + change["repo"] + "/" + change["path"])
        copies = sum(change["after"] is not None for change in changes)
        print("Copies: " + str(copies) + "; old file locations to remove: " + str(len(changes) - copies) + ".")
        if "Diamond" not in roots:
            print("Diamond was not selected and will not be changed.")
        if not changes:
            print("Nothing to change; the selected checklist files already match.")
        elif arguments.apply:
            apply_changes(changes, roots)
        else:
            print("Preview only. Nothing changed. Add --apply to back up and transfer the files.")
        return 0
    except (OSError, TransferError, ValueError) as error:
        print("ERROR: " + str(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
