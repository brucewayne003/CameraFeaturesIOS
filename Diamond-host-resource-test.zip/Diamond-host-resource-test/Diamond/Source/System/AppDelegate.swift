//
//  AppDelegate.swift
//  diamond-ios
//
//  Created by Andrew HunzekerHesed on 4/29/23.
//

import Bogle
import Combine
import Osiris
import UIKit

@main
@available(iOS 15.0, *)
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    var coordinator: AppCoordinator?
    var cancellables: Set<AnyCancellable> = []
    @Provider var requestManager: RequestManagerProtocol = RequestManager()
    let userState: UserState = .shared
    let environmentManager: EnvironmentManager = .shared

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        let resources = DiamondResourceProvider()
        resources.registerFonts()
        OsirisUIResourceRegistry.provider = resources

        window = UIWindow(frame: UIScreen.main.bounds)
        let navigationController = UINavigationController()
        coordinator = AppCoordinator(navigationController: navigationController)

        window?.rootViewController = navigationController
        window?.makeKeyAndVisible()

        setupSessionSubscriptions()
        setupServices()

        coordinator?.start()

        return true
    }
    
    // MARK: Private Helpers
    
    private func setupSessionSubscriptions() {
        userState.$session
            .dropFirst()
            .receive(on: DispatchQueue.main)
            .sink { [weak self] session in
            switch session {
            case .loggedOut, .expired:
                self?.coordinator?.showLogin()
            case .loggedIn:
                self?.coordinator?.showHomeTab()
            }
        }
        .store(in: &cancellables)
    }
    
    private func setupServices() {
        let settingsService = UserDefaultBarcodeSettingsService(defaults: .standard)
        BarcodeSettingsService.start(withService: settingsService)
    }
    
}

private struct DiamondResourceProvider: OsirisResourceProvider {
    func color(named name: String) -> UIColor? {
        switch name {
        case "blue100": return .systemBlue
        case "yellow100": return .systemYellow
        default: return UIColor(named: name, in: .main, compatibleWith: nil)
        }
    }

    func image(named name: String) -> UIImage? {
        switch name {
        case "ic_flash": return UIImage(systemName: "flashlight.on.fill")
        case "ic_flash_slash": return UIImage(systemName: "flashlight.off.fill")
        default: return UIImage(named: name, in: .main, compatibleWith: nil)
        }
    }

    func registerFonts() {
        _ = UIFont.registerBogle()
        _ = UIFont.registerBogleMono()
    }

    func font(named name: String, size: CGFloat) -> UIFont? {
        UIFont(name: name, size: size)
    }
}
